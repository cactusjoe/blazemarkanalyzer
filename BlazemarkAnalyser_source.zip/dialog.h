#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QAbstractButton>
#include <QDebug>

#include <db/SqliteConnector.h>
#include <db/DatabaseQuery.h>
#include <entities/Library.h>
#include <entities/Version.h>
#include <entities/Build.h>
#include <entities/Param.h>
#include <entities/TestCategory.h>
#include <entities/Sweep.h>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit Dialog(QWidget *parent = 0);
    inline void setConn(SqliteConnector * myConn) { m_conn = myConn; m_query = new DatabaseQuery(m_conn);}
    void makeVersionDialog(Library * myLibrary, Version * newVersion);
    void makeBuildDialog(Version * myVersion, Build * newBuild);
    void makeParamDialog(TestCategory * myTestCategory, Param * newParam);
    void makeSweepDialog(Test * myTest, Build * myBuild, QString BuildN, Sweep * newSweep);
    void makeSweepManagementDialog(QList<Sweep*>* selectedSweeps, QList<int> *counts, Sweep** targetSweep, QString buildN);
    void makeRemoveDialog(Version * myVersion, SqliteConnector * myConn);
    void makeRemoveDialog(Build * myBuild, SqliteConnector * myConn);
    void updateSweep();
    void resetElements();
    ~Dialog();
    
private slots:

    void on_buttons_clicked(QAbstractButton *button);

    void on_nameInput_editingFinished();

    void on_secondaryInput_editingFinished();

    void on_thirdInput_editingFinished();

    void on_dimEdit_editingFinished();

    void on_comboBox_currentIndexChanged(const QString &arg1);

    void on_acceptButton_clicked();

    void on_deleteButton_clicked();

    void on_comboBox_currentIndexChanged(int index);

    void on_cancelButton_clicked();

private:
    Ui::Dialog *ui;
    SqliteConnector * m_conn;
    DatabaseQuery * m_query;
    Version * m_newVersion;
    Build * m_newBuild;
    Param * m_newParam;
    Sweep * m_newSweep;
    Sweep ** m_newSweepPtr;
    QList<Sweep*>* m_sweepList;
    QList<int>* m_intList;
    QString m_mode;
};

#endif // DIALOG_H
