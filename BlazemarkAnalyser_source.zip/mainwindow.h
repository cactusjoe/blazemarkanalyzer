#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidgetItem>
#include <QTableWidgetItem>
#include <QListWidget>
#include <QProcess>
#include <QThread>
#include <QGraphicsScene>
#include <QSettings>
#include "dialog.h"

#include <entities/Test.h>
#include <entities/Library.h>
#include <entities/TestCategory.h>
#include <entities/Param.h>
#include <entities/TestCase.h>
#include <entities/Version.h>
#include <entities/TestResult.h>
#include <entities/Sweep.h>
#include <entities/SweepResult.h>
#include <db/DatabaseConnector.h>
#include <db/SqliteConnector.h>
#include <db/DatabaseQuery.h>
#include <process/BlazemarkProcessor.h>
#include <defines.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT


public:
    explicit MainWindow(QWidget *parent = 0);

    //This function loads all entities from the database
    void loadEntities();

    //This function selects the library that is active in the GUI selection list and loads the versions associated with it
    void selectLibrary();

    //This function selects the version that is active in the GUI selection list and loads the builds associated with it
    void selectVersion();

    //This function selects the build that is active in the GUI selection list
    void selectBuild();

    //This function selects the test that is active in the GUI selection list
    void selectTest();

    void selectGraphLibrary();

    void selectGraphVersion();

    void selectGraphTest();

    void updateGraphButton();

    //This function fills the GUI list with the params associated with the selected test
    void loadParams();

    //This function shows the results of the active builds and selected test on the GUI
    void loadResults();

    //This function deletes the selected results from the database
    void clearResults();

    void showGraph(bool addBuild);

    void showSweep();

    void clearGraph();

    //This function starts the process thread running the selected test
    void runCurrentTest();

    void continueSweep();

    void runSpecialTest();

    //This function saves the new test results to the database
    void processResult(int dim, float nzrF, QString result, Test * myTest, Build * myBuild);

    void processSweepResult(float paramF, QString result);

    //This function orders the given params in ascending order
    void sortParams(QList<Param> * paramList);
    void sortParams(QList<Param*> * paramList);

    //This function orders the given testcases by params in ascending order
    void sortTestCases(QList<TestCase> * testCaseList);

    void sortTestResults(QList<TestResult*> * testResultList);

    //This function parses the Blazemark name of a test to give a description name
    void parseTestName();

    //This function parses the given Blazemark test output to get a TestResult object
    void parseBlazemarkOutput(QString myOutput, Test * myTest, Library * myLibrary, Build * myBuild);

    ~MainWindow();

private slots:
    void exitProgram();

    void processReady();

    void processError();

    void on_testList_itemClicked(QListWidgetItem *);

    void on_testList_itemSelectionChanged();

    void on_libraryList_itemClicked(QListWidgetItem *);

    void on_libraryList_itemSelectionChanged();

    void on_versionList_itemSelectionChanged();

    void on_versionList_itemClicked(QListWidgetItem *);

    void on_buildList_itemClicked(QListWidgetItem *);

    void on_buildList_itemSelectionChanged();

    void on_startTestButton_clicked();

    void on_delResultsButton_clicked();

    void on_removeBuildButton_clicked();

    void on_removeVersionButton_clicked();

    void on_addVersionButton_clicked();

    void on_addBuildButton_clicked();

    void on_clearGraphButton_clicked();

    void on_graphTestList_currentIndexChanged(int);

    void on_graphLibraryList_currentIndexChanged(int);

    void on_graphVersionList_currentIndexChanged(int);

    void on_graphBuildList_currentIndexChanged(int);

    void on_addGraphButton_clicked();

    void on_compareModeRadio_toggled(bool checked);

    void on_sweepModeRadio_toggled(bool checked);

    void on_specButton_clicked();

private:
    Ui::MainWindow* ui;
    SqliteConnector* m_conn;
    Dialog m_dialog;
    QList<Library>* m_libraries;
    Library* m_selectedLibrary;
    QList<Version>* m_versions;
    Version* m_selectedVersion;
    QList<Test>* m_tests;
    QList<Test*>* m_runTests;
    Test* m_selectedTest;
    QList<Build>* m_builds;
    QList<Build*>* m_runBuilds;
    Build* m_selectedBuild;
    QList<Param>* m_params;
    QList<Param*>* m_shownParams;
    QList<Param*>* m_runParams;
    Param* m_selectedParam;
    QList<TestCategory>* m_testCategories;
    QList<TestCase>* m_testCases;
    TestCase* m_selectedTestCase;
    QList<TestResult>* m_testResults;
    QList<TestResult*>* m_shownResults;
    QSet<TestResult*>* m_graphResults;
    TestResult* m_selectedTestResult;
    QList<Sweep>* m_sweeps;
    QList<Sweep*>* m_selectedSweeps;
    QList<Sweep*>* m_shownSweeps;
    QList<SweepResult>* m_sweepResults;
    DatabaseQuery* m_query;
    BlazemarkProcessor* m_processor;
    Sweep * m_runningSweep;
    QProcess* m_process;
    QThread* m_procThread;
    QGraphicsScene* m_scene;
    QGraphicsScene* m_descScene;
    QSettings* m_settings;
    bool m_working;
    int m_testRunning;
    int m_runID;
    int m_graphBuildCount;
    int m_graphMode;
    int m_sweepProgress;
    int m_specInt;
};

#endif // MAINWINDOW_H
