#include "dialog.h"
#include "ui_dialog.h"

#include <entities/Build.h>
#include <entities/TestResult.h>

#include <QDesktopWidget>
#include <QAbstractButton>
#include <QDebug>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    m_mode = "";
    m_newVersion = NULL;
    m_newParam = NULL;
    m_newBuild = NULL;
    m_conn = NULL;
    m_query = NULL;
    ui->setupUi(this);
}

void Dialog::makeVersionDialog(Library * myLibrary, Version * newVersion) {
    m_mode = "Version";
    this->setWindowTitle("New version");
    m_newVersion = newVersion;
    m_newVersion->setLibraryId(myLibrary->getLibraryId());
    resetElements();
    this->setGeometry(0, 0, 270, 300);
    ui->buttons->setOrientation(Qt::Horizontal);
    ui->buttons->setGeometry(40, 260, 170, 30);
    ui->buttons->clear();
    ui->buttons->addButton(QDialogButtonBox::Save);
    ui->buttons->addButton(QDialogButtonBox::Cancel);
    ui->buttons->show();
    ui->messageText->setGeometry(30, 10, 200, 40);
    ui->messageText->setAlignment(Qt::AlignLeft);
    ui->messageText->setText("New version for library\n" + myLibrary->getName());
    ui->messageText->show();
    ui->nameInput->setGeometry(30, 60, 210, 27);
    ui->nameInput->setText("Revision");
    ui->nameInput->show();
    ui->descBox->setGeometry(30, 100, 210, 100);
    ui->descBox->setText("Comment");
    ui->descBox->show();
    ui->dateInput->setGeometry(30, 220, 210, 27);
    ui->dateInput->setDate(QDate::currentDate());
    ui->dateInput->show();
    QRect scr = QApplication::desktop()->screenGeometry();
    move( scr.center() - rect().center() );
}

void Dialog::makeBuildDialog(Version * myVersion, Build * newBuild) {
    m_mode = "Build";
    this->setWindowTitle("New build");
    m_newBuild = newBuild;
    m_newBuild->setVersionId(myVersion->getVersionId());
    resetElements();
    this->setGeometry(0, 0, 800, 150);
    ui->buttons->setOrientation(Qt::Vertical);
    ui->buttons->setGeometry(680, 10, 105, 80);
    ui->buttons->clear();
    ui->buttons->addButton(QDialogButtonBox::Save);
    ui->buttons->addButton(QDialogButtonBox::Cancel);
    ui->buttons->show();
    ui->messageText->setGeometry(30, 20, 380, 20);
    ui->messageText->setAlignment(Qt::AlignLeft);
    ui->messageText->setText("New build for version " + myVersion->getRevision());
    ui->messageText->show();
    ui->nameInput->setGeometry(30, 50, 630, 27);
    ui->nameInput->setText("Build options");
    ui->nameInput->show();
    ui->descBox->setGeometry(30, 90, 630, 50);
    ui->descBox->setText("Comment");
    ui->descBox->show();
    QRect scr = QApplication::desktop()->screenGeometry();
    move( scr.center() - rect().center() );
}

void Dialog::makeParamDialog(TestCategory * myTestCategory, Param * newParam) {
    /*MAKE PARAM DIALOG*/
}

void Dialog::makeSweepDialog(Test *myTest, Build *myBuild, QString BuildN, Sweep *newSweep) {
    m_mode = "Sweep";
    this->setWindowTitle("New sweep");
    m_newSweep = newSweep;
    m_newSweep->setBuildId(myBuild->getBuildId());
    m_newSweep->setTestId(myTest->getTestId());
    m_newSweep->setParentBuild(myBuild);
    m_newSweep->setParentTest(myTest);
    resetElements();
    this->setGeometry(0, 0, 300, 323);
    ui->buttons->setOrientation(Qt::Horizontal);
    ui->buttons->setGeometry(65, 280, 171, 31);
    ui->buttons->clear();
    ui->buttons->addButton(QDialogButtonBox::Save);
    ui->buttons->addButton(QDialogButtonBox::Cancel);
    ui->buttons->show();
    ui->messageText->setGeometry(30, 10, 421, 40);
    ui->messageText->setAlignment(Qt::AlignLeft);
    ui->messageText->setText("New sweep for test " + myTest->getName() + "\n" + myBuild->getParentVersion()->getParentLibrary()->getName() + " " + myBuild->getParentVersion()->getRevision() + " " + BuildN);
    ui->messageText->show();
    ui->comboBox->setGeometry(30, 70, 241, 27);
    ui->comboBox->clear();
    ui->comboBox->addItem("Dimension sweep");
    if(myTest->getParentTestCategory()->getName().at(0) == 's') {
        ui->comboBox->addItem("Nonzero count sweep");
        ui->dimEdit->setGeometry(158, 110, 113, 27);
        ui->dimEdit->setText("Density (%)");
        ui->dimEdit->show();
        ui->comboBox->show();
        ui->comboBox->setCurrentIndex(0);
        ui->nameInput->setGeometry(30, 110, 91, 27);
        ui->nameInput->setText("Sweep start");
        ui->nameInput->show();
        ui->secondaryInput->setGeometry(30, 150, 91, 27);
        ui->secondaryInput->setText("Sweep end");
        ui->secondaryInput->show();
        ui->thirdInput->setGeometry(30, 190, 91, 27);
        ui->thirdInput->setText("Step count");
        ui->thirdInput->show();
    } else {
        ui->comboBox->show();
        ui->comboBox->setCurrentIndex(0);
        ui->nameInput->setGeometry(30, 110, 241, 27);
        ui->nameInput->setText("Sweep start");
        ui->nameInput->show();
        ui->secondaryInput->setGeometry(30, 150, 241, 27);
        ui->secondaryInput->setText("Sweep end");
        ui->secondaryInput->show();
        ui->thirdInput->setGeometry(30, 190, 241, 27);
        ui->thirdInput->setText("Step count");
        ui->thirdInput->show();
    }
    ui->radio_1->setGeometry(30, 230, 191, 22);
    ui->radio_1->setText("Linear scaling");
    ui->radio_1->setChecked(true);
    ui->radio_1->show();
    ui->radio_2->setGeometry(30, 250, 191, 22);
    ui->radio_2->setText("Logarithmic scaling");
    ui->radio_2->show();

    QRect scr = QApplication::desktop()->screenGeometry();
    move( scr.center() - rect().center() );
}

void Dialog::makeSweepManagementDialog(QList<Sweep*> *selectedSweeps, QList<int> * counts, Sweep **targetSweep, QString buildN) {
    m_mode ="SweepManagementWorking";
    m_sweepList = selectedSweeps;
    m_intList = counts;
    m_newSweepPtr = targetSweep;
    this->setWindowTitle("Manage sweeps");
    resetElements();
    this->setGeometry(0, 0, 631, 236);
    ui->messageText->setGeometry(30, 20, 421, 51);
    ui->messageText->setAlignment(Qt::AlignLeft);
    ui->messageText->setText("Sweep for test " + m_sweepList->at(0)->getParentTest()->getName() + "\n" + m_sweepList->at(0)->getParentBuild()->getParentVersion()->getParentLibrary()->getName() +
                             " " + m_sweepList->at(0)->getParentBuild()->getParentVersion()->getRevision() + " " + buildN);
    ui->messageText->show();
    ui->comboBox->setGeometry(30, 70, 571, 27);
    ui->comboBox->clear();
    ui->comboBox->show();
    ui->infoLabel->setGeometry(30, 110, 361, 71);
    ui->infoLabel->setAlignment(Qt::AlignLeft);
    ui->infoLabel->show();
    ui->acceptButton->setGeometry(160, 190, 99, 27);
    ui->acceptButton->show();
    ui->deleteButton->setGeometry(270, 190, 99, 27);
    ui->deleteButton->setText("Delete");
    ui->deleteButton->show();
    ui->cancelButton->setGeometry(380, 190, 99, 27);
    ui->cancelButton->setText("Cancel");
    ui->cancelButton->show();
    for(int index = 0; index < m_sweepList->count(); index++) {
        ui->comboBox->addItem((m_sweepList->at(index)->getNonzeros() == -2 ? QString("Nonzero count sweep from ") : QString("Dimension sweep from ")) +
                              QString::number(m_sweepList->at(index)->getSweepMin()) + QString(" to ") +
                              QString::number(m_sweepList->at(index)->getSweepMax()) + QString(" (") +
                              QString::number(m_sweepList->at(index)->getSweepCount()) + QString(" steps)"), m_sweepList->at(index)->getSweepId());
        ui->comboBox->setCurrentIndex(0);
    }
    int idx = -1;
    while(m_sweepList->at(++idx)->getSweepId() != ui->comboBox->itemData(ui->comboBox->currentIndex()));
    (*m_newSweepPtr) = m_sweepList->operator [](idx);
    m_mode ="SweepManagement";
    updateSweep();

    QRect scr = QApplication::desktop()->screenGeometry();
    move( scr.center() - rect().center() );
}

void Dialog::makeRemoveDialog(Build *myBuild, SqliteConnector * myConn) {
    m_conn = myConn;
    m_query = new DatabaseQuery(m_conn);
    m_mode = "BuildRemove";
    this->setWindowTitle("Remove build");
    m_newBuild = myBuild;
    resetElements();
    this->setGeometry(0, 0, 400, 120);
    ui->buttons->setOrientation(Qt::Horizontal);
    ui->buttons->setGeometry(50, 80, 280, 30);
    ui->buttons->clear();
    ui->buttons->addButton(QDialogButtonBox::Yes);
    ui->buttons->addButton(QDialogButtonBox::No);
    ui->buttons->show();
    ui->messageText->setGeometry(10, 20, 380, 50);
    ui->messageText->setAlignment(Qt::AlignHCenter);
    ui->messageText->setText("Are you sure you want to remove selected build?\n(All result associated with build will be cleared.)");
    ui->messageText->show();
    QRect scr = QApplication::desktop()->screenGeometry();
    move( scr.center() - rect().center() );
}

void Dialog::makeRemoveDialog(Version *myVersion, SqliteConnector * myConn) {
    m_conn = myConn;
    m_query = new DatabaseQuery(m_conn);
    m_mode = "VersionRemove";
    this->setWindowTitle("Remove version");
    m_newVersion = myVersion;
    resetElements();
    this->setGeometry(0, 0, 400, 120);
    ui->buttons->setOrientation(Qt::Horizontal);
    ui->buttons->setGeometry(50, 80, 280, 30);
    ui->buttons->clear();
    ui->buttons->addButton(QDialogButtonBox::Yes);
    ui->buttons->addButton(QDialogButtonBox::No);
    ui->buttons->show();
    ui->messageText->setGeometry(10, 20, 380, 50);
    ui->messageText->setAlignment(Qt::AlignHCenter);
    ui->messageText->setText("Are you sure you want to remove selected version?\n(All result associated with version will be cleared.)");
    ui->messageText->show();
    QRect scr = QApplication::desktop()->screenGeometry();
    move( scr.center() - rect().center() );
}

void Dialog::updateSweep() {
    if(m_mode == "SweepManagement") {
        int swID = -1;
        while(m_sweepList->at(++swID)->getSweepId() != ui->comboBox->itemData(ui->comboBox->currentIndex()));
        ui->infoLabel->setText((m_sweepList->at(swID)->getNonzeros() == -1 ? QString("") : (m_sweepList->at(swID)->getNonzeros() == -2 ? (QString("Dimension: ") + QString::number(m_sweepList->at(swID)->getDimension()) + QString("\n")) : (QString("Sparsity: ") + QString::number(m_sweepList->at(swID)->getNonzeros()) + QString("%\n")))) +
                               (m_sweepList->at(swID)->getScaling() == "logarithmic" ? QString("Logarithmic scaling\n") : QString("Linear scaling\n")) +
                               QString::number(qRound((float)m_intList->at(swID) * 100 / (float)m_sweepList->at(swID)->getSweepCount())) + QString("% complete"));
        if(m_intList->at(swID) == m_sweepList->at(swID)->getSweepCount()) {
            ui->acceptButton->setText("Show");
        } else {
            ui->acceptButton->setText("Continue");
        }
        (*m_newSweepPtr) = m_sweepList->operator [](swID);
    }
}

void Dialog::resetElements() {
    ui->dateInput->hide();
    ui->descBox->hide();
    ui->messageText->hide();
    ui->nameInput->hide();
    ui->secondaryInput->hide();
    ui->thirdInput->hide();
    ui->thirdInput->hide();
    ui->comboBox->hide();
    ui->dimEdit->hide();
    ui->nzrEdit->hide();
    ui->radio_1->hide();
    ui->radio_2->hide();
    ui->acceptButton->hide();
    ui->deleteButton->hide();
    ui->cancelButton->hide();
    ui->infoLabel->hide();
    ui->buttons->hide();
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_buttons_clicked(QAbstractButton *button)
{
    if(button->text() == "&Save" || button->text() == "&Yes") {
        if(m_mode == "Version") {
            m_newVersion->setRevision(ui->nameInput->text());
            m_newVersion->setReleaseDate(QDateTime(ui->dateInput->date()));
            m_newVersion->setNote(ui->descBox->toPlainText());
            m_newVersion->save();
        }
        if(m_mode == "Build") {
            m_newBuild->setOptions(ui->nameInput->text());
            m_newBuild->setNote(ui->descBox->toPlainText());
            m_newBuild->save();
        }
        if(m_mode == "Sweep") {
            on_thirdInput_editingFinished();
            if(m_newSweep->getParentTest()->getParentTestCategory()->getName().at(0) == 'd')
                m_newSweep->setNonzeros(-1);
            if(ui->comboBox->currentText() == "Dimension sweep") {
                m_newSweep->setDimension(-2);
                if(m_newSweep->getParentTest()->getParentTestCategory()->getName().at(0) == 's')
                    m_newSweep->setNonzeros(ui->dimEdit->text().toFloat());
            }
            if(ui->comboBox->currentText() == "Nonzero count sweep") {
                m_newSweep->setNonzeros(-2);
                m_newSweep->setDimension(ui->dimEdit->text().toInt());
            }
            m_newSweep->setSweepMin(ui->nameInput->text().toFloat());
            m_newSweep->setSweepMax(ui->secondaryInput->text().toFloat());
            m_newSweep->setSweepCount(ui->thirdInput->text().toInt());
            if(ui->radio_1->isChecked()) {
                m_newSweep->setScaling("linear");
            } else {
                m_newSweep->setScaling("logarithmic");
            }
            m_newSweep->save();
        }
        if(m_mode == "BuildRemove") {
            QList<TestResult> * testResults = new QList<TestResult>;
            m_query->loadTestResultsByBuild(testResults, m_newBuild);
            for(int index = 0; index < testResults->count(); index++) {
                (testResults->operator [](index)).remove();
            }
            m_newBuild->remove();
        }
        if(m_mode == "VersionRemove") {
            QList<Build> * builds = new QList<Build>;
            QList<TestResult> * testResults = new QList<TestResult>;
            m_query->loadBuildsByVersion(builds, m_newVersion);
            for(int index = 0; index < builds->count(); index++) {
                m_query->loadTestResultsByBuild(testResults, &(builds->operator [](index)));
            }
            for(int index = 0; index < testResults->count(); index++) {
                (testResults->operator [](index)).remove();
            }
            m_newVersion->remove();
        }
    }
}

void Dialog::on_nameInput_editingFinished()
{
    if(m_mode == "Sweep") {
        if(ui->comboBox->currentText() == "Dimension sweep" && ui->nameInput->text().toInt() < 1) {
            ui->nameInput->setText("1000");
        }
        if(ui->comboBox->currentText() == "Nonzero count sweep" && (ui->nameInput->text().toFloat() == 0 || ui->nameInput->text().toFloat() == 100)) {
            ui->nameInput->setText("0.1");
        }
    }
}

void Dialog::on_secondaryInput_editingFinished()
{
    if(m_mode == "Sweep") {
        on_nameInput_editingFinished();
        if(ui->comboBox->currentText() == "Dimension sweep" && ui->secondaryInput->text().toInt() <= ui->nameInput->text().toInt()) {
            ui->secondaryInput->setText(QString::number(ui->nameInput->text().toInt() * 10));
        }
        if(ui->comboBox->currentText() == "Nonzero count sweep" && (ui->secondaryInput->text().toFloat() <= ui->nameInput->text().toFloat() || ui->secondaryInput->text().toFloat() > 100)) {
            ui->secondaryInput->setText("100");
        }
    }
}

void Dialog::on_thirdInput_editingFinished()
{
    if(m_mode == "Sweep") {
        on_secondaryInput_editingFinished();
        if(ui->comboBox->currentText() == "Dimension sweep" && ui->thirdInput->text().toInt() < 2) {
            ui->thirdInput->setText("100");
        }
        if(ui->comboBox->currentText() == "Nonzero count sweep" && ui->thirdInput->text().toInt() < 2) {
            ui->thirdInput->setText("100");
        }
    }
}

void Dialog::on_dimEdit_editingFinished()
{
    if(m_mode == "Sweep" && m_newSweep->getParentTest()->getParentTestCategory()->getName().at(0) != 'd') {
        if(ui->comboBox->currentText() == "Dimension sweep" && (ui->dimEdit->text().toFloat() == 0 || ui->dimEdit->text().toFloat() > 100)) {
            ui->dimEdit->setText("0.1");
        }
        if(ui->comboBox->currentText() == "Nonzero count sweep" && ui->dimEdit->text().toInt() == 0) {
            ui->dimEdit->setText("10000");
        }
    }
}

void Dialog::on_comboBox_currentIndexChanged(const QString &arg1)
{
    on_nameInput_editingFinished();
    if(m_mode == "Sweep") {
        if(ui->comboBox->currentText() == "Dimension sweep") {
            ui->dimEdit->setText("Nonzeros (%)");
        }
        if(ui->comboBox->currentText() == "Nonzero count sweep") {
            ui->dimEdit->setText("Dimension");
        }
    }
}

void Dialog::on_acceptButton_clicked()
{
    accept();
}

void Dialog::on_deleteButton_clicked()
{
    (*m_newSweepPtr)->remove();
    (*m_newSweepPtr)->setParentBuild(NULL);
    (*m_newSweepPtr)->setParentTest(NULL);
    accept();
}

void Dialog::on_comboBox_currentIndexChanged(int index)
{
    if(m_mode == "SweepManagement") updateSweep();
}

void Dialog::on_cancelButton_clicked()
{
    (*m_newSweepPtr) = NULL;
    accept();
}
