#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>
#include <QDir>
#include <QFile>
#include <QThread>
#include <QProcess>
#include <QDialog>
#include <QGraphicsItem>
#include <QtCore/qmath.h>

void MainWindow::loadEntities() {

    m_working = true;

    //Clearing entity container lists
    m_libraries->clear();
    m_versions->clear();
    m_builds->clear();
    m_testCategories->clear();
    m_tests->clear();
    m_testCases->clear();
    m_testResults->clear();

    m_query->generateSampleData();
    //Loading test categories
    m_query->loadTestCategories(m_testCategories);

    //Tests are not loaded by category to maintain original order
    m_query->loadTests(m_tests);

    //!!!!!!!!!TODO HANDLE MATTRANS TESTS
    for(int i = 0; i < m_tests->count();)
        if(m_tests->at(i).getName() == "dmattrans" || m_tests->at(i).getName() == "smattrans") {
            m_tests->removeAt(i); } else { i++; }

    //Loading params
    for(int index = 0; index < m_testCategories->count(); index++)
        m_query->loadParamsByTestCategory(m_params, &(m_testCategories->operator [](index)));

    //Loading testcases and setting testcategory pointers for tests
    for(int index = 0; index < m_tests->count(); index++) {
        int currentCatIndex = -1;
        while(m_tests->at(index).getTestCategoryId() != m_testCategories->at(++currentCatIndex).getTestCategoryId());
        (m_tests->operator [](index)).setParentTestCategory(&(m_testCategories->operator [](currentCatIndex)));
        m_query->loadTestCasesByTest(m_testCases, &(m_tests->operator [](index)));
    }

    //Setting param pointers for testcases
    for(int index = 0; index < m_testCases->count(); index++) {
        int currentParamIndex = -1;
        while(m_testCases->at(index).getParamId() != m_params->at(++currentParamIndex).getParamId());
        (m_testCases->operator [](index)).setParentParam(&(m_params->operator [](currentParamIndex)));
    }

    //Loading libraries
    m_query->loadLibraries(m_libraries);

    //Loading library versions
    for(int index = 0; index < m_libraries->count(); index++)
        m_query->loadVersionsByLibrary(m_versions, &(m_libraries->operator [](index)));

    //Loading version builds
    for(int index = 0; index < m_versions->count(); index++)
        m_query->loadBuildsByVersion(m_builds, &(m_versions->operator [](index)));

    //Loading stored results
    for(int index = 0; index < m_builds->count(); index++)
        for(int index2 = 0; index2 < m_testCases->count(); index2++)
            m_query->loadTestResultsByAll(m_testResults, &(m_builds->operator [](index)), &(m_testCases->operator [](index2)));

    //Loading sweeps
    for(int index = 0; index < m_builds->count(); index++)
        for(int index2 = 0; index2 < m_tests->count(); index2++)
            m_query->loadSweepsByAll(m_sweeps, &(m_tests->operator [](index2)), &(m_builds->operator [](index)));

    //Filling up GUI library list
    ui->libraryList->clear();
    QListWidgetItem * newItem;
    for(int index = 0; index < m_libraries->count(); index++) {
        newItem = new QListWidgetItem;
        newItem->setText(m_libraries->at(index).getName());
        newItem->setData(32, m_libraries->at(index).getLibraryId());
        ui->libraryList->addItem(newItem);
    }
    if(ui->libraryList->count() > 0) {
        ui->libraryList->setCurrentRow(0);
        selectLibrary();
    }

    //Filling up GUI test lists
    ui->testList->clear();
    for(int index = 0; index < m_tests->count(); index++) {
        newItem = new QListWidgetItem;
        newItem->setText(m_tests->at(index).getName());
        newItem->setData(32, m_tests->at(index).getTestId());
        ui->testList->addItem(newItem);
        ui->graphTestList->addItem(m_tests->at(index).getName(), m_tests->at(index).getTestId());

    }
    if(ui->testList->count() > 0) {
        ui->testList->setCurrentRow(0);
        selectTest();
        selectGraphTest();
    }
    m_working = false;
}

void MainWindow::selectLibrary() {
    m_working = true;
    if(ui->libraryList->selectedItems().count() > 0) {
        int index = -1;
        while(m_libraries->at(++index).getLibraryId() != ui->libraryList->selectedItems().at(0)->data(32).toInt());
        m_selectedLibrary = &(m_libraries->operator [](index));
        ui->libraryDescription->setText(m_selectedLibrary->getNote());
        ui->libraryAuthorLabel->setText(QString("Author - ") + m_selectedLibrary->getAuthor());
        ui->libraryUrlLabel->setText(QString("<a href=\"") + m_selectedLibrary->getUrl() + QString("\">") +
                                     m_selectedLibrary->getUrl() + QString("</a>"));

        //Filling up GUI version list
        ui->versionList->clear();
        QListWidgetItem * newItem;
        for(index = 0; index < m_versions->count(); index++) {
            if(m_versions->at(index).getParentLibrary() == m_selectedLibrary) {
                newItem = new QListWidgetItem;
                newItem->setText(m_versions->at(index).getRevision());
                newItem->setData(32, m_versions->at(index).getVersionId());
                ui->versionList->addItem(newItem);
            }
        }
        if(ui->versionList->count() > 0) {
            ui->versionList->setCurrentRow(ui->versionList->count() - 1);
            selectVersion();
        }
    }
    m_working = false;
}

void MainWindow::selectVersion() {
    m_working = true;
    if(ui->versionList->selectedItems().count() > 0) {
        int index = -1;
        while(m_versions->at(++index).getVersionId() != ui->versionList->selectedItems().at(0)->data(32).toInt());
        m_selectedVersion = &(m_versions->operator [](index));
        ui->versionDescription->setText(m_selectedVersion->getNote());
        ui->versionDateLabel->setText(QString("Release date: ") + m_selectedVersion->getReleaseDate().date().toString("yyyy. MM. dd."));

        //Filling up GUI build list
        ui->buildList->clear();
        QListWidgetItem * newItem;
        m_runBuilds->clear();
        for(int index = 0; index < m_builds->count(); index++) {
            if(m_builds->at(index).getParentVersion() == m_selectedVersion) {
                newItem = new QListWidgetItem;
                newItem->setText(QString::number(index + 1) + " - " + m_builds->at(index).getOptions());
                newItem->setData(32, m_builds->at(index).getBuildId());
                newItem->setFlags(newItem->flags() | Qt::ItemIsUserCheckable);
                ui->buildList->addItem(newItem);
                newItem->setCheckState(Qt::Checked);
                m_runBuilds->append(&(m_builds->operator [](index)));
            }
        }
        if(ui->buildList->count() > 0) {
            ui->buildList->setCurrentRow(0);
            selectBuild();
        }
    }
    m_working = false;
}

void MainWindow::selectBuild() {
    m_working = true;
    if(ui->buildList->selectedItems().count() > 0) {
        int index = -1;
        while(m_builds->at(++index).getBuildId() != ui->buildList->selectedItems().at(0)->data(32).toInt());
        m_selectedBuild = &(m_builds->operator [](index));
        loadResults();
    }
    m_working = false;
}

void MainWindow::selectTest() {
    m_working = true;
    if(ui->testList->selectedItems().count() > 0) {
        int index = -1;
        while(m_tests->at(++index).getTestId() != ui->testList->selectedItems().at(0)->data(32).toInt());
        m_selectedTest = &(m_tests->operator [](index));
        m_runTests->clear();
        m_runTests->append(m_selectedTest);
        parseTestName();
        loadParams();
        loadResults();
    }
    m_working = false;
}

void MainWindow::selectGraphLibrary() {
    m_working = true;
    if(ui->graphLibraryList->currentIndex() != -1) {
        if(m_graphMode == 0) {
            ui->graphVersionList->clear();
            ui->graphBuildList->clear();
            QSet<Version*>* updatedVersions = new QSet<Version*>;
            for(int index = 0; index < m_testResults->count(); index++) {
                if(m_testResults->at(index).getParentBuild()->getParentVersion()->getParentLibrary()->getLibraryId() == ui->graphLibraryList->itemData(ui->graphLibraryList->currentIndex()) && m_testResults->at(index).getParentTestCase()->getParentTest()->getTestId() == ui->graphTestList->itemData(ui->graphTestList->currentIndex()))
                    updatedVersions->insert(m_testResults->at(index).getParentBuild()->getParentVersion());
            }
            for(int index = 0; index < updatedVersions->count(); index++) {
                ui->graphVersionList->addItem(updatedVersions->values().at(index)->getRevision(), updatedVersions->values().at(index)->getVersionId());
            }
            selectGraphVersion();
        }
        if(m_graphMode == 1) {
            ui->graphVersionList->clear();
            ui->graphBuildList->clear();
            for(int index = 0; index < m_versions->count(); index++)
                if(m_versions->at(index).getLibraryId() == ui->graphLibraryList->itemData(ui->graphLibraryList->currentIndex()))
                    ui->graphVersionList->addItem(m_versions->at(index).getRevision(), m_versions->at(index).getVersionId());
            selectGraphVersion();
        }
    }
    m_working = false;
}

void MainWindow::selectGraphVersion() {
    m_working = true;
    if(ui->graphVersionList->currentIndex() != -1) {
        if(m_graphMode == 0) {
            ui->graphBuildList->clear();
            QSet<Build*>* updatedBuilds = new QSet<Build*>;
            for(int index = 0; index < m_testResults->count(); index++) {
                if(m_testResults->at(index).getParentBuild()->getParentVersion()->getVersionId() == ui->graphVersionList->itemData(ui->graphVersionList->currentIndex()) && m_testResults->at(index).getParentTestCase()->getParentTest()->getTestId() == ui->graphTestList->itemData(ui->graphTestList->currentIndex()))
                    updatedBuilds->insert(m_testResults->at(index).getParentBuild());
            }
            for(int index = 0; index < updatedBuilds->count(); index++) {
                QList<Build>* IDDeterminants = new QList<Build>;
                m_query->loadBuildsByVersion(IDDeterminants, updatedBuilds->values().at(index)->getParentVersion());
                int ID = 0;
                while(IDDeterminants->at(ID++).getBuildId() != updatedBuilds->values().at(index)->getBuildId());
                ui->graphBuildList->addItem(QString("Build " + QString::number(ID)), updatedBuilds->values().at(index)->getBuildId());
            }
            updateGraphButton();
        }
        if(m_graphMode == 1) {
            ui->graphBuildList->clear();
            int ID = 0;
            for(int index = 0; index < m_builds->count(); index++)
                if(m_builds->at(index).getVersionId() == ui->graphVersionList->itemData(ui->graphVersionList->currentIndex())) {
                    ID++;
                    ui->graphBuildList->addItem(QString("Build " + QString::number(ID)), m_builds->at(index).getBuildId());
                }
            updateGraphButton();
        }
    }
    m_working = false;
}

void MainWindow::selectGraphTest() {
    m_working = true;
        if(ui->graphTestList->currentIndex() != -1) {
            ui->graphLibraryList->clear();
            ui->graphVersionList->clear();
            ui->graphBuildList->clear();
            QSet<Library*>* updatedLibraries = new QSet<Library*>;
            for(int index = 0; index < m_testResults->count(); index++) {
                if(m_testResults->at(index).getParentTestCase()->getParentTest()->getTestId() == ui->graphTestList->itemData(ui->graphTestList->currentIndex()))
                    updatedLibraries->insert(m_testResults->at(index).getParentBuild()->getParentVersion()->getParentLibrary());
            }
            for(int index = 0; index < updatedLibraries->count(); index++) {
                ui->graphLibraryList->addItem(updatedLibraries->values().at(index)->getName(), updatedLibraries->values().at(index)->getLibraryId());
            }
            selectGraphLibrary();
        }
    m_working = false;
}

void MainWindow::updateGraphButton() {
    m_working = true;
    if(m_graphMode == 0) {
        if(ui->graphBuildList->currentIndex() != -1) {
            int nowCount = m_graphResults->count();
            for(int index = 0; index < m_graphResults->count(); index++)
                if(m_graphResults->values().at(index)->getParentBuild()->getBuildId() == ui->graphBuildList->itemData(ui->graphBuildList->currentIndex()) && m_graphResults->values().at(index)->getParentTestCase()->getParentTest()->getTestId() == ui->graphTestList->itemData(ui->graphTestList->currentIndex()))
                    nowCount--;
            if(nowCount < m_graphResults->count()) {
                ui->addGraphButton->setText("Remove build results");
            } else {
                ui->addGraphButton->setText("Add build results");
            }
        }
    }
    if(m_graphMode == 1 && ui->graphBuildList->currentIndex() >= 0) {
        m_selectedSweeps->clear();
        int testID = -1, buildID = -1;
        while(ui->graphTestList->itemData(ui->graphTestList->currentIndex()) != m_tests->at(++testID).getTestId());
        while(ui->graphBuildList->itemData(ui->graphBuildList->currentIndex()) != m_builds->at(++buildID).getBuildId());
        for(int index = 0; index < m_sweeps->count(); index++) {
            if(m_sweeps->at(index).getBuildId() == m_builds->at(buildID).getBuildId() && m_sweeps->at(index).getTestId() == m_tests->at(testID).getTestId()) {
                m_selectedSweeps->append(&(m_sweeps->operator [](index)));
            }
        }
        if(m_selectedSweeps->count() == 0) {
            ui->clearGraphButton->setDisabled(1);
        } else {
            ui->clearGraphButton->setDisabled(0);
        }
    }
    m_working = false;
}

void MainWindow::loadParams() {
    if(m_selectedTest != NULL) {
        m_working = true;
        m_shownParams->clear();
        if(m_selectedTest->getName() != "svecinit") {
            for(int index = 0; index < m_params->count(); index++) {
                if(m_params->at(index).getParentTestCategory() == m_selectedTest->getParentTestCategory())
                    m_shownParams->append(&(m_params->operator [](index)));
            }
        } else {
            for(int index = 0; index < m_params->count(); index++) {
                if(m_params->at(index).getParamId() == 6)
                    m_shownParams->append(&(m_params->operator [](index)));
            }
        }

        while(ui->paramTable->rowCount() > 0) ui->paramTable->removeRow(0);
        ui->paramTable->clear();
        if(m_selectedTest->getParentTestCategory()->getName()[0] == 'd') {
            ui->paramTable->setColumnCount(2);
            ui->paramTable->setHorizontalHeaderLabels(QStringList() << QString("Dimension"));
            ui->paramTable->setColumnWidth(0, 258);
            ui->paramTable->setColumnWidth(1, 0);
        } else {
            ui->paramTable->setColumnCount(3);
            ui->paramTable->setColumnWidth(0, 129);
            ui->paramTable->setColumnWidth(1, 129);
            ui->paramTable->setColumnWidth(2, 0);
            ui->paramTable->setHorizontalHeaderLabels(QStringList() << QString("Dimension") << QString("Density"));
        }
        int index = 0;
        sortParams(m_shownParams);
        QTableWidgetItem * newItem;
        for(; index < m_shownParams->count(); index++) {
            ui->paramTable->insertRow(ui->paramTable->rowCount());
            newItem = new QTableWidgetItem();
            newItem->setTextAlignment(Qt::AlignRight);
            newItem->setText(QString::number(m_shownParams->at(index)->getDimension()));
            ui->paramTable->setItem(index, 0, newItem);
            if(m_shownParams->at(index)->getNonzeros() >= 0) {
                newItem = new QTableWidgetItem();
                newItem->setTextAlignment(Qt::AlignRight);
                newItem->setText(QString::number(100 * (float)m_shownParams->at(index)->getNonzeros() / (float)m_shownParams->at(index)->getDimension()) + " %");
                ui->paramTable->setItem(index, 1, newItem);
                newItem = new QTableWidgetItem();
                newItem->setText(QString::number(m_shownParams->at(index)->getParamId()));
                ui->paramTable->setItem(index, 2, newItem);
            } else {
                newItem = new QTableWidgetItem();
                newItem->setText(QString::number(m_shownParams->at(index)->getParamId()));
                ui->paramTable->setItem(index, 1, newItem);
            }
        }
        m_working = false;
    }
}

//!!!!!!!!!TODO THIS FUNCTION NEEDS TO BE UPDATED - USE NEW ENTITY POINTERS INSTEAD OF QUERIES
void MainWindow::loadResults() {
    if(m_selectedLibrary != NULL && m_selectedTest != NULL && m_params->count() != 0) {
        int index, index2, index3, index4; bool title, results = false;
        QList<Build> * curBuilds = new QList<Build>;
        QList<Param> * curParams = new QList<Param>;
        QList<TestResult> * curResults = new QList<TestResult>;
        QList<TestCase> * curCases = new QList<TestCase>;
        QList<TestResult> * curShownResults = new QList<TestResult>;
        curCases->clear();
        curShownResults->clear();
        m_query->loadTestCasesByTest(curCases, m_selectedTest);
        m_query->loadParams(curParams);
        sortParams(curParams);
        sortTestCases(curCases);
        ui->resultLabel->clear();
        QString newLabel = "", measurement = "MFlops";
        if(m_selectedTest->getName() == "dmattrans" || m_selectedTest->getName() == "smattrans") measurement = "Seconds";
        newLabel += "<table width=\"1000px\">";
        for(index = 0; index < curCases->count(); index++) {
            m_query->loadTestResultsByTestCase(curShownResults, &(curCases->operator [](index)));
        }
        for(index = 0; index < m_versions->count(); index++) {
            curBuilds->clear();
            m_query->loadBuildsByVersion(curBuilds, &(m_versions->operator [](index)));
            for(index2 = 0; index2 < curBuilds->count(); index2++) {
                m_query->loadTestResultsByBuild(curShownResults, &(curBuilds->operator [](index2)));
                newLabel += "<th width=\"650\" align=\"left\">" +(curBuilds->at(index2).getParentVersion()->getParentLibrary()->getName() + " - " + m_versions->at(index).getRevision() + " - Build " + QString::number(index2 + 1)) + "</th>";
                title = false;
                for(index3 = 0; index3 < curCases->count(); index3++) {
                    curResults->clear();
                    m_query->loadTestResultsByAll(curResults, &(curBuilds->operator [](index2)), &(curCases->operator [](index3)));
                    if(curResults->count() > 0) {
                        if(curResults->at(0).getTestResult() == "Operation not supported by build." || curResults->at(0).getTestResult() == "Test time limit reached.") {
                            newLabel += "<tr><td width=\"10\"></td><td width=\"150\" align=\"right\"></td><td width=\"150\" align=\"right\"><b>" +
                                    curResults->at(0).getTestResult() + "</b></td><td width=\"150\" align=\"right\"></td></tr>";
                            title = true;
                        } else {
                            if(!title) {
                                newLabel += "<tr><td width=\"10\"></td><td width=\"150\" align=\"right\"><b>Elements</b></td><td width=\"150\" align=\"right\"><b>Density</b></td><td width=\"150\" align=\"right\"><b>" + measurement + "</b></td></tr>";
                                title = true;
                            }
                            index4 = -1;
                            while(curCases->at(index3).getParamId() != m_params->at(++index4).getParamId());
                            newLabel += "<tr><td width=\"10\"></td><td width=\"150\" align=\"right\">" + QString::number(m_params->at(index4).getDimension()) +
                                    "</td><td width=\"150\" align=\"right\">" + ((m_params->at(index4).getNonzeros() > 0) ? (QString::number(100 * (float)m_params->at(index4).getNonzeros() / (float)m_params->at(index4).getDimension())) : (QString("100"))) +
                                    " %</td><td width=\"150\" align=\"right\">" + curResults->at(0).getTestResult() + "</td></tr>";
                         }
                    }
                }
                if(!title) {
                    newLabel += "<tr><td width=\"10\"></td><td width=\"150\" align=\"right\">No results.</td></tr>";
                } else {
                    results = true;
                }
            }
        }
        if(!results) {
            ui->delResultsButton->setDisabled(true);
        } else {
            ui->delResultsButton->setDisabled(false);
        }
        newLabel += "</table>";
        ui->resultLabel->setText(newLabel);
        ui->resultLabel->setGeometry(15,15,741, (ui->resultLabel->fontMetrics().lineSpacing() + 7) * (7 + ui->resultLabel->text().count("<tr>") + ui->resultLabel->text().count("<th>")));
    }
}

void MainWindow::clearResults() {
    while(m_shownResults->count() > 0) {
        (m_shownResults->operator [](0))->remove();
        m_shownResults->removeAt(0);
    }

    //Reloading stored results
    for(int index = 0; index < m_builds->count(); index++)
        for(int index2 = 0; index2 < m_testCases->count(); index2++)
            m_query->loadTestResultsByAll(m_testResults, &(m_builds->operator [](index)), &(m_testCases->operator [](index2)));

    selectTest();
}

void MainWindow::showGraph(bool addBuild = true) {
    m_working = true;
    if(ui->graphBuildList->currentIndex() != -1) {
        if(m_graphResults->count() > 0 && ui->graphTestList->itemData(ui->graphTestList->currentIndex()) != m_graphResults->values().at(0)->getParentTestCase()->getParentTest()->getTestId()) {
            m_graphResults->clear();
            m_graphBuildCount = 0;
        }
        int nowCount = m_graphResults->count();
        if(addBuild) {
            for(int index = 0; index < m_testResults->count(); index++)
                if(m_testResults->at(index).getParentBuild()->getBuildId() == ui->graphBuildList->itemData(ui->graphBuildList->currentIndex()) && m_testResults->at(index).getParentTestCase()->getParentTest()->getTestId() == ui->graphTestList->itemData(ui->graphTestList->currentIndex()))
                    m_graphResults->insert(&(m_testResults->operator [](index)));
            if(m_graphResults->count() > nowCount)
                m_graphBuildCount++;
        } else {
            QSet<TestResult*> minusResults;
            for(int index = 0; index < m_graphResults->count(); index++)
                if(m_graphResults->values().at(index)->getParentBuild()->getBuildId() == ui->graphBuildList->itemData(ui->graphBuildList->currentIndex()) && m_graphResults->values().at(index)->getParentTestCase()->getParentTest()->getTestId() == ui->graphTestList->itemData(ui->graphTestList->currentIndex()))
                    minusResults.insert(m_graphResults->values().operator [](index));
            m_graphResults->subtract(minusResults);
            m_graphBuildCount--;
        }
        if(m_graphBuildCount == 0) { clearGraph(); } else {
            QGraphicsItem* tempItem;
            m_descScene = new QGraphicsScene(QRect(0, 0, ui->graphDescView->geometry().width() - 2, ui->graphDescView->geometry().height() - 2));
            m_descScene->addRect(QRectF(0, 0, m_descScene->width() - 1, m_descScene->height() - 1));
            m_scene = new QGraphicsScene(QRect(0, 0, ui->graphView->geometry().width() - 2, ui->graphView->geometry().height() - 2));
            m_scene->addRect(QRectF(0, 0, m_scene->width() - 1, m_scene->height() - 1));
            m_scene->addLine(19, 0, 20, m_scene->height() - 1);
            m_scene->addLine(20, 51, m_scene->width() - 1, 51, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 50 + (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 50 + 2 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 2 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 50 + 3 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 3 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 50 + 4 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 4 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 50 + 5 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 5 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 50 + 6 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 6 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 50 + 7 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 7 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
            m_scene->addLine(20, 51, 30, 51);
            m_scene->addLine(20, 50 + (m_scene->height() - 100) / 4, 30, 50 + (m_scene->height() - 100) / 4);
            m_scene->addLine(20, 50 + 2 * (m_scene->height() - 100) / 4, 30, 50 + 2 * (m_scene->height() - 100) / 4);
            m_scene->addLine(20, 50 + 3 * (m_scene->height() - 100) / 4, 30, 50 + 3 * (m_scene->height() - 100) / 4);
            int sectionSize = (m_scene->width() - 103) / m_graphBuildCount;
            int graphSize;
            nowCount = 0;
            qreal maxResult = 0;
            for(int index = 0; index < m_graphResults->count(); index++)
                if(m_graphResults->values().at(index)->getTestResult().toFloat() > maxResult)
                    maxResult = m_graphResults->values().at(index)->getTestResult().toFloat();
            tempItem = m_scene->addText("MFLOPS");
            tempItem->moveBy(25, 5);
            tempItem = m_scene->addText(m_graphResults->values().at(0)->getParentTestCase()->getParentTest()->getName().toUpper());
            tempItem->moveBy((m_scene->width() - 1) / 2 - (tempItem->boundingRect().width() / 2), 5);
            tempItem = m_scene->addText(QString::number(maxResult, 'f', 2));
            tempItem->moveBy(33, 30);
            tempItem = m_scene->addText(QString::number(maxResult * 3 / 4, 'f', 2));
            tempItem->moveBy(33, 28 + (m_scene->height() - 100) / 4);
            tempItem = m_scene->addText(QString::number(maxResult / 2, 'f', 2));
            tempItem->moveBy(33, 28 + 2 * (m_scene->height() - 100) / 4);
            tempItem = m_scene->addText(QString::number(maxResult / 4, 'f', 2));
            tempItem->moveBy(33, 28 + 3 * (m_scene->height() - 100) / 4);
            QSet<Build*>* drawnBuilds = new QSet<Build*>;
            Build* currentBuild;
            QList<TestResult*>* curGraphs = new QList<TestResult*>;
            QList<Param*>* usedParams = new QList<Param*>;
            QList<QColor> colorList;
            colorList << QColor(79, 129, 189) << QColor(192, 80, 77) << QColor(155, 187, 89) << QColor(172, 98, 62) << QColor(239, 169, 37) << QColor(208, 51, 225) << QColor(210, 223, 53) << QColor(35, 5, 124) << QColor(7, 70, 0) << QColor(255, 255, 255);
            for(int index = 0; index < m_graphBuildCount; index++) {
                currentBuild = NULL;
                curGraphs->clear();
                for(int index2 = 0; index2 < m_graphResults->count(); index2++) {
                    if(currentBuild == NULL && !drawnBuilds->contains(m_graphResults->values().at(index2)->getParentBuild()))
                        currentBuild = m_graphResults->values().at(index2)->getParentBuild();
                    if(currentBuild != NULL && m_graphResults->values().at(index2)->getBuildId() == currentBuild->getBuildId())
                        curGraphs->append(m_graphResults->values().at(index2));
                }
                sortTestResults(curGraphs);
                graphSize = sectionSize / (curGraphs->count() + 2);
                int colorNum = 0;
                tempItem = m_descScene->addText("dimension / density");
                tempItem->moveBy((m_descScene->width() - 1) / 2 - (tempItem->boundingRect().width() / 2), 5);
                for(int index2 = 0; index2 < curGraphs->count(); index2++) {
                    colorNum = usedParams->indexOf(curGraphs->at(index2)->getParentTestCase()->getParentParam());
                    if(colorNum == -1 && curGraphs->at(index2)->getTestResult().toFloat() != 0) {
                        colorNum = usedParams->count();
                        usedParams->append(curGraphs->at(index2)->getParentTestCase()->getParentParam());
                        m_descScene->addRect(20, 20 * (colorNum + 1) + 20, 10, 10, QPen(QColor("white")), QBrush(colorList.at(colorNum)));
                        if(usedParams->at(colorNum)->getNonzeros() == -1) {
                            tempItem = m_descScene->addText(QString::number(usedParams->at(colorNum)->getDimension()) + " / 100%");
                        } else {
                            tempItem = m_descScene->addText(QString::number(usedParams->at(colorNum)->getDimension()) + " / " + QString::number(100 * (float)usedParams->at(colorNum)->getNonzeros() / (float)usedParams->at(colorNum)->getDimension()) + "%");
                        }
                            tempItem->moveBy(33, 20 * (colorNum + 1) + 12);
                    }
                    if(curGraphs->at(index2)->getTestResult().toFloat() != 0) {
                        m_scene->addRect(QRectF(103 + index * sectionSize + (1 + index2) * graphSize,
                                         m_scene->height() - qFloor((float)(m_scene->height() - 100) * ((float)curGraphs->at(index2)->getTestResult().toFloat() / (float)maxResult)) - 50,
                                         graphSize,
                                         qFloor((float)(m_scene->height() - 100) * ((float)curGraphs->at(index2)->getTestResult().toFloat() / (float)maxResult))),
                                         QPen(QColor("white")),
                                         colorNum == -1 ? QBrush(QColor("black")) : QBrush(QColor(colorList.at(colorNum))));
                    } else {
                        tempItem = m_scene->addText("OPERATION\nNOT SUPPORTED\nBY BUILD");
                        tempItem->moveBy(103 + index * sectionSize + 0.5 * sectionSize - tempItem->boundingRect().width() / 2, m_scene->height() - 120);
                    }
                }
                QList<Build>* IDDeterminants = new QList<Build>;
                m_query->loadBuildsByVersion(IDDeterminants, currentBuild->getParentVersion());
                int ID = 0;
                while(IDDeterminants->at(ID++).getBuildId() != currentBuild->getBuildId());
                tempItem = m_scene->addText(currentBuild->getParentVersion()->getParentLibrary()->getName());
                tempItem->moveBy(103 + index * sectionSize + sectionSize * 0.5 - tempItem->boundingRect().width() / 2, m_scene->height() - 48);
                tempItem = m_scene->addText(currentBuild->getParentVersion()->getRevision() + QString(" - Build ") + QString::number(ID));
                tempItem->moveBy(103 + index * sectionSize + sectionSize * 0.5 - tempItem->boundingRect().width() / 2, m_scene->height() - 28);
                drawnBuilds->insert(currentBuild);
            }
            m_scene->addLine(20, m_scene->height() - 50, m_scene->width() - 1, m_scene->height() - 50);
            m_scene->addLine(0, m_scene->height() - 218, 0, m_scene->height() - 2, QPen(QColor("white")));
            m_descScene->addLine(m_descScene->width() - 1, 1, m_descScene->width() - 1, m_descScene->height() - 1, QPen(QColor("white")));
            ui->graphView->setScene(m_scene);
            ui->graphDescView->setScene(m_descScene);
            updateGraphButton();
        }
    }
    m_working =false;
}

void MainWindow::showSweep() {
    m_working = true;
    if(m_shownSweeps->count() > 0) {
        m_sweepResults->clear();
        for(int index = 0; index < m_shownSweeps->count(); index++)
            m_query->loadSweepResultsBySweep(m_sweepResults, m_shownSweeps->operator [](index));
        int index2, min = 0;
        for(int index = 0; index < m_sweepResults->count() - 1; index++) {
            min = index;
            for(index2 = index + 1; index2 < m_sweepResults->count(); index2++)
                if(m_sweepResults->at(index2).getParamValue() < m_sweepResults->at(min).getParamValue())
                    min = index2;
            if(min != index) {
                m_sweepResults->move(min, index);
                m_sweepResults->move(index + 1, min);
            }
        }
        QGraphicsItem* tempItem;
        m_descScene = new QGraphicsScene(QRect(0, 0, ui->graphDescView->geometry().width() - 2, ui->graphDescView->geometry().height() - 2));
        m_descScene->addRect(QRectF(0, 0, m_descScene->width() - 1, m_descScene->height() - 1));
        m_scene = new QGraphicsScene(QRect(0, 0, ui->graphView->geometry().width() - 2, ui->graphView->geometry().height() - 2));
        m_scene->addRect(QRectF(0, 0, m_scene->width() - 1, m_scene->height() - 1));
        m_scene->addLine(19, 0, 20, m_scene->height() - 1);
        m_scene->addLine(20, 51, m_scene->width() - 1, 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 50 + (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 50 + 2 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 2 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 50 + 3 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 3 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 50 + 4 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 4 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 50 + 5 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 5 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 50 + 6 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 6 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 50 + 7 * (m_scene->height() - 100) / 8, m_scene->width() - 1, 50 + 7 * (m_scene->height() - 100) / 8, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(20, 51, 30, 51);
        m_scene->addLine(20, 50 + (m_scene->height() - 100) / 4, 30, 50 + (m_scene->height() - 100) / 4);
        m_scene->addLine(20, 50 + 2 * (m_scene->height() - 100) / 4, 30, 50 + 2 * (m_scene->height() - 100) / 4);
        m_scene->addLine(20, 50 + 3 * (m_scene->height() - 100) / 4, 30, 50 + 3 * (m_scene->height() - 100) / 4);
        m_scene->addLine(60 + (m_scene->width() - 80) / 8, 51, 60 + (m_scene->width() - 80) / 8, m_scene->height() - 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(60 + 2 * (m_scene->width() - 80) / 8, 51, 60 + 2 * (m_scene->width() - 80) / 8, m_scene->height() - 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(60 + 3 * (m_scene->width() - 80) / 8, 51, 60 + 3 * (m_scene->width() - 80) / 8, m_scene->height() - 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(60 + 4 * (m_scene->width() - 80) / 8, 51, 60 + 4 * (m_scene->width() - 80) / 8, m_scene->height() - 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(60 + 5 * (m_scene->width() - 80) / 8, 51, 60 + 5 * (m_scene->width() - 80) / 8, m_scene->height() - 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(60 + 6 * (m_scene->width() - 80) / 8, 51, 60 + 6 * (m_scene->width() - 80) / 8, m_scene->height() - 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(60 + 7 * (m_scene->width() - 80) / 8, 51, 60 + 7 * (m_scene->width() - 80) / 8, m_scene->height() - 51, QPen(QColor(0, 0, 0, 55)));
        m_scene->addLine(60 + (m_scene->width() - 80) / 8, m_scene->height() - 61, 60 + (m_scene->width() - 80) / 8, m_scene->height() - 51);
        m_scene->addLine(60 + 3 * (m_scene->width() - 80) / 8, m_scene->height() - 61, 60 + 3 * (m_scene->width() - 80) / 8, m_scene->height() - 51);
        m_scene->addLine(60 + 5 * (m_scene->width() - 80) / 8, m_scene->height() - 61, 60 + 5 * (m_scene->width() - 80) / 8, m_scene->height() - 51);
        m_scene->addLine(60 + 7 * (m_scene->width() - 80) / 8, m_scene->height() - 61, 60 + 7 * (m_scene->width() - 80) / 8, m_scene->height() - 51);
        qreal maxResult = 0, maxParam = 0, minParam = -1;
        for(int index = 0; index < m_sweepResults->count(); index++) {
            if(m_sweepResults->at(index).getResult().toFloat() > maxResult)
                maxResult = m_sweepResults->at(index).getResult().toFloat();
            if(m_sweepResults->at(index).getParamValue() > maxParam)
                maxParam = m_sweepResults->at(index).getParamValue();
            if(m_sweepResults->at(index).getParamValue() < minParam || minParam == -1)
                minParam = m_sweepResults->at(index).getParamValue();
        }
        if(m_shownSweeps->at(0)->getDimension() == -2) {
            tempItem = m_scene->addText("DIMENSION");
            tempItem->moveBy(m_scene->width() - 100, m_scene->height() - 80);
        }
        if(m_shownSweeps->at(0)->getNonzeros() == -2) {
            tempItem = m_scene->addText("DENSITY");
            tempItem->moveBy(m_scene->width() - 100, m_scene->height() - 80);
        }
        tempItem = m_scene->addText("MFLOPS");
        tempItem->moveBy(25, 5);
        if(m_shownSweeps->at(0)->getDimension() == -2) {
            if(m_shownSweeps->at(0)->getNonzeros() == -1) {
                tempItem = m_scene->addText(m_shownSweeps->at(0)->getParentTest()->getName().toUpper() + " - SWEEP");
                tempItem->moveBy((m_scene->width() - 1) / 2 - (tempItem->boundingRect().width() / 2), 5);
            } else {
                tempItem = m_scene->addText(m_shownSweeps->at(0)->getParentTest()->getName().toUpper() + " - SWEEP WITH " + QString::number(m_shownSweeps->at(0)->getNonzeros()) + "% DENSITY");
                tempItem->moveBy((m_scene->width() - 1) / 2 - (tempItem->boundingRect().width() / 2), 5);
            }
        }
        if(m_shownSweeps->at(0)->getNonzeros() == -2) {
            tempItem = m_scene->addText(m_shownSweeps->at(0)->getParentTest()->getName().toUpper() + " - SWEEP WITH " + QString::number(m_shownSweeps->at(0)->getDimension()) + " DIMENSION");
            tempItem->moveBy((m_scene->width() - 1) / 2 - (tempItem->boundingRect().width() / 2), 5);
        }
        tempItem = m_scene->addText(QString::number(maxResult, 'f', 2));
        tempItem->moveBy(33, 30);
        tempItem = m_scene->addText(QString::number(maxResult * 3 / 4, 'f', 2));
        tempItem->moveBy(33, 28 + (m_scene->height() - 100) / 4);
        tempItem = m_scene->addText(QString::number(maxResult / 2, 'f', 2));
        tempItem->moveBy(33, 28 + 2 * (m_scene->height() - 100) / 4);
        tempItem = m_scene->addText(QString::number(maxResult / 4, 'f', 2));
        tempItem->moveBy(33, 28 + 3 * (m_scene->height() - 100) / 4);
        tempItem = m_scene->addText(QString::number(minParam));
        tempItem->moveBy(30 + (m_scene->width() - 80) / 8, m_scene->height() - 40);
        tempItem = m_scene->addText(QString::number(maxParam));
        tempItem->moveBy(30 + 7 * (m_scene->width() - 80) / 8, m_scene->height() - 40);
        if(m_shownSweeps->at(0)->getScaling() == "logarithmic") {
            if(m_shownSweeps->at(0)->getDimension() == -2) {
                qreal PVal = qRound(qPow(10, ((qLn(minParam) / qLn(10)) + ((qLn(maxParam) / qLn(10)) - (qLn(minParam) / qLn(10))) / 3)));
                tempItem = m_scene->addText(QString::number(PVal));
                tempItem->moveBy(30 + 3 * (m_scene->width() - 80) / 8, m_scene->height() - 40);
                PVal = qRound(qPow(10, ((qLn(minParam) / qLn(10)) + 2 * ((qLn(maxParam) / qLn(10)) - (qLn(minParam) / qLn(10))) / 3)));
                tempItem = m_scene->addText(QString::number(PVal));
                tempItem->moveBy(30 + 5 * (m_scene->width() - 80) / 8, m_scene->height() - 40);
            } else {
                qreal PVal = qPow(10, ((qLn(minParam) / qLn(10)) + ((qLn(maxParam) / qLn(10)) - (qLn(minParam) / qLn(10))) / 3));
                tempItem = m_scene->addText(QString::number(PVal, 'f', 3));
                tempItem->moveBy(30 + 3 * (m_scene->width() - 80) / 8, m_scene->height() - 40);
                PVal = qPow(10, ((qLn(minParam) / qLn(10)) + 2 * ((qLn(maxParam) / qLn(10)) - (qLn(minParam) / qLn(10))) / 3));
                tempItem = m_scene->addText(QString::number(PVal));
                tempItem->moveBy(30 + 5 * (m_scene->width() - 80) / 8, m_scene->height() - 40);
            }
        } else {
            tempItem = m_scene->addText(QString::number(minParam + (maxParam - minParam) / 3));
            tempItem->moveBy(30 + 3 * (m_scene->width() - 80) / 8, m_scene->height() - 40);
            tempItem = m_scene->addText(QString::number(minParam + 2 * (maxParam - minParam) / 3));
            tempItem->moveBy(30 + 5 * (m_scene->width() - 80) / 8, m_scene->height() - 40);
        }
        QList<QColor> colorList;
        int prevID = -1, curID = 0;
        colorList << QColor(79, 129, 189) << QColor(192, 80, 77) << QColor(155, 187, 89) << QColor(172, 98, 62) << QColor(239, 169, 37) << QColor(208, 51, 225) << QColor(210, 223, 53) << QColor(35, 5, 124) << QColor(7, 70, 0) << QColor(255, 255, 255);
        for(int swidx = 0; swidx < m_shownSweeps->count(); swidx++) {
            curID = 0; prevID = -1; QPen myPen;
            for(int ridx = 0; ridx < m_sweepResults->count(); ridx++) {
                myPen.setColor(colorList.at(swidx));
                myPen.setWidth(3);
                if(m_sweepResults->at(ridx).getSweepId() == m_shownSweeps->at(swidx)->getSweepId()) {
                    if(prevID != -1) {
                        m_scene->addLine((60 + ((m_scene->width() - 80) / 8)) + curID * ((6 * (m_scene->width() - 80) / 8) / (m_shownSweeps->at(swidx)->getSweepCount() - 1)),
                                         51 + (m_scene->height() - 100) * ((maxResult - m_sweepResults->at(prevID).getResult().toFloat()) / maxResult),
                                         (60 + ((m_scene->width() - 80) / 8)) + (curID + 1) * ((6 * (m_scene->width() - 80) / 8) / (m_shownSweeps->at(swidx)->getSweepCount() - 1)),
                                         51 + (m_scene->height() - 100) * ((maxResult - m_sweepResults->at(ridx).getResult().toFloat()) / maxResult),
                                         myPen);
                        curID++;
                    }
                    prevID = ridx;
                }
            }
            tempItem = m_descScene->addText("BUILDS");
            tempItem->moveBy((m_descScene->width() - 1) / 2 - (tempItem->boundingRect().width() / 2), 5);
            m_descScene->addRect(20, 20 * (swidx + 1) + 20, 10, 10, QPen(QColor("white")), QBrush(colorList.at(swidx)));
            tempItem = m_descScene->addText(m_shownSweeps->at(swidx)->getParentBuild()->getParentVersion()->getParentLibrary()->getName() + " " + m_shownSweeps->at(swidx)->getParentBuild()->getParentVersion()->getRevision());
            tempItem->moveBy(33, 20 * (swidx + 1) + 12);
        }
        m_scene->addLine(20, m_scene->height() - 50, m_scene->width() - 1, m_scene->height() - 50);
        m_scene->addLine(0, m_scene->height() - 218, 0, m_scene->height() - 2, QPen(QColor("white")));
        m_descScene->addLine(m_descScene->width() - 1, 1, m_descScene->width() - 1, m_descScene->height() - 1, QPen(QColor("white")));
        ui->graphView->setScene(m_scene);
        ui->graphDescView->setScene(m_descScene);
    } else { clearGraph(); }
    m_working = false;
}

void MainWindow::clearGraph() {
    m_graphResults->clear();
    m_graphBuildCount = 0;
    QGraphicsItem* tempItem;
    m_scene = new QGraphicsScene(QRect(0, 0, ui->graphView->geometry().width() - 2, ui->graphView->geometry().height() - 2));
    m_scene->addRect(QRectF(0, 0, m_scene->width() - 1, m_scene->height() - 1));
    tempItem = m_scene->addText("NO RESULTS ADDED");
    tempItem->moveBy((m_scene->width() - 1) / 2 - (tempItem->boundingRect().width() / 2), (m_scene->height() - 1) / 2 - (tempItem->boundingRect().height() / 2));
    m_scene->addLine(0, m_scene->height() - 218, 0, m_scene->height() - 2, QPen(QColor("white")));
    m_descScene = new QGraphicsScene(QRect(0, 0, ui->graphDescView->geometry().width() - 2, ui->graphDescView->geometry().height() - 2));
    m_descScene->addRect(QRectF(0, 0, m_descScene->width() - 1, m_descScene->height() - 1));
    m_descScene->addLine(m_descScene->width() - 1, 1, m_descScene->width() - 1, m_descScene->height() - 1, QPen(QColor("white")));
    ui->graphView->setScene(m_scene);
    ui->graphDescView->setScene(m_descScene);
    ui->graphView->show();
    ui->graphDescView->show();
    updateGraphButton();
}

void MainWindow::runCurrentTest() {
    if((m_runBuilds->count() > m_runID && m_runTests->count() == 1) || (m_runBuilds->count() == 1 && m_runTests->count() > m_runID)) {
        ui->startTestButton->setText("Working...");
        ui->startTestButton->setDisabled(1);
        ui->removeBuildButton->setDisabled(1);
        ui->specButton->setDisabled(1);
        ui->removeVersionButton->setDisabled(1);
        if(m_graphMode == 1)
            ui->addGraphButton->setDisabled(1);
        m_testRunning = 1;
        m_processor = new BlazemarkProcessor();
        m_procThread = new QThread();
        if(m_runTests->count() == 1) {
            m_processor->setTest(m_runTests->operator [](0));
        } else {
            m_processor->setTest(m_runTests->operator [](m_runID));
        }
        m_processor->setLibrary(m_selectedLibrary);
        if(m_runBuilds->count() == 1) {
            m_processor->setBuild(m_runBuilds->operator [](0));
        } else {
            m_processor->setBuild(m_runBuilds->operator [](m_runID));
        }
        m_runID++;
        m_processor->setParams(m_runParams);
        m_processor->moveToThread(m_procThread);
        connect(m_procThread, SIGNAL(started()), m_processor, SLOT(process()));
        connect(m_processor, SIGNAL(error()), this, SLOT(processError()));
        connect(m_processor, SIGNAL(finished()), this, SLOT(processReady()));
        m_procThread->start();
    }
}

void MainWindow::continueSweep() {
    if(m_runningSweep != NULL && (m_testRunning == 0 || m_testRunning == 2)) {
        QList<SweepResult> * resultsSoFar = new QList<SweepResult>;
        m_query->loadSweepResultsBySweep(resultsSoFar, m_runningSweep);
        if(resultsSoFar->count() >= m_runningSweep->getSweepCount()) {
            m_testRunning = 0;
            ui->startTestButton->setText("Run selected tests");
            ui->startTestButton->setDisabled(0);
            ui->removeBuildButton->setDisabled(0);
            ui->specButton->setDisabled(0);
            ui->removeVersionButton->setDisabled(0);
            if(m_graphMode == 1) {
                ui->addGraphButton->setDisabled(0);
                ui->addGraphButton->setText("New sweep..");
            }
            m_runningSweep = NULL;

            //Reload sweeps
            m_working = true;
            m_sweeps->clear();
            for(int index = 0; index < m_builds->count(); index++)
                for(int index2 = 0; index2 < m_tests->count(); index2++)
                    m_query->loadSweepsByAll(m_sweeps, &(m_tests->operator [](index2)), &(m_builds->operator [](index)));
            m_working = false;
            updateGraphButton();
        } else {
            ui->startTestButton->setText("Working...");
            ui->startTestButton->setDisabled(1);
            ui->removeBuildButton->setDisabled(1);
            ui->removeVersionButton->setDisabled(1);
            ui->specButton->setDisabled(1);
            m_testRunning = 2;
            m_processor = new BlazemarkProcessor();
            m_procThread = new QThread();
            m_processor->setTest(m_runningSweep->getParentTest());
            m_processor->setLibrary(m_runningSweep->getParentBuild()->getParentVersion()->getParentLibrary());
            m_processor->setBuild(m_runningSweep->getParentBuild());

            QList<Param*> * sweepParams = new QList<Param*>;
            Param ** newParam;
            for(int index = 0; index < 10; index++) {
                *newParam = new Param(m_conn);
                if(m_runningSweep->getDimension() == -2) {
                    int nextVal = m_runningSweep->getSweepMin();
                    if(m_runningSweep->getScaling() == "linear") {
                        nextVal = nextVal + (index + resultsSoFar->count()) * ((m_runningSweep->getSweepMax() - nextVal) / (m_runningSweep->getSweepCount() - 1));
                    }
                    if(m_runningSweep->getScaling() == "logarithmic") {
                        qreal nextPower = qLn(nextVal) / qLn(10);
                        nextPower = nextPower + ((index + resultsSoFar->count()) * (((qLn(m_runningSweep->getSweepMax()) / qLn(10)) - nextPower) / (m_runningSweep->getSweepCount() - 1)));
                        nextVal = qRound(qPow(10, nextPower));
                    }
                    (*newParam)->setDimension(nextVal);
                } else {
                    (*newParam)->setDimension(m_runningSweep->getDimension());
                }
                if(m_runningSweep->getNonzeros() == -2) {
                    qreal nextVal = m_runningSweep->getSweepMin();
                    if(m_runningSweep->getScaling() == "linear") {
                        nextVal = nextVal + (index + resultsSoFar->count()) * ((m_runningSweep->getSweepMax() - nextVal) / (float)(m_runningSweep->getSweepCount() - 1));
                    }
                    if(m_runningSweep->getScaling() == "logarithmic") {
                        qreal nextPower = qLn(nextVal) / qLn(10);
                        nextPower = nextPower + ((index + resultsSoFar->count()) * (((qLn(m_runningSweep->getSweepMax()) / qLn(10)) - nextPower) / (m_runningSweep->getSweepCount() - 1)));
                        nextVal = qPow(10, nextPower);
                    }
                    (*newParam)->setNonzeros(qRound(nextVal * (*newParam)->getDimension() / 100));
                } else {
                    (*newParam)->setNonzeros(qRound(m_runningSweep->getNonzeros() * (*newParam)->getDimension() / 100));
                    if((*newParam)->getNonzeros() == 0) (*newParam)->setNonzeros(1);
                }
                if(sweepParams->count() + resultsSoFar->count() < m_runningSweep->getSweepCount()) sweepParams->append(*newParam);
            }
            m_processor->setParams(sweepParams);

            m_sweepProgress = qRound(100 * (float)(resultsSoFar->count()) / (float)m_runningSweep->getSweepCount());
            if(m_sweepProgress == 100) m_sweepProgress--;
            if(m_graphMode == 1)
                ui->addGraphButton->setText(QString("Cancel sweep (") + QString::number(m_sweepProgress) + QString("%)"));

            m_processor->moveToThread(m_procThread);
            connect(m_procThread, SIGNAL(started()), m_processor, SLOT(process()));
            connect(m_procThread, SIGNAL(finished()), m_procThread, SLOT(deleteLater()));
            connect(m_processor, SIGNAL(error()), this, SLOT(processError()));
            connect(m_processor, SIGNAL(finished()), this, SLOT(processReady()));
            m_procThread->start();
        }
    }
}

void MainWindow::runSpecialTest() {
    int maxProgress = m_tests->count() * 9;
    if(m_specInt < maxProgress) {
        ui->startTestButton->setText("Working...");
        ui->startTestButton->setDisabled(1);
        ui->removeBuildButton->setDisabled(1);
        ui->specButton->setDisabled(1);
        ui->removeVersionButton->setDisabled(1);
        if(m_graphMode == 1)
            ui->addGraphButton->setDisabled(1);
        m_testRunning = 3;
        m_processor = new BlazemarkProcessor();
        m_procThread = new QThread();
        m_runParams->clear();
        if(maxProgress / 9 > m_specInt) {
            for(int index = 0; index < m_params->count(); index++) {
                if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt).getParentTestCategory()->getTestCategoryId())
                    m_runParams->append(&(m_params->operator [](index)));
            }
            for(int index = 0; index < m_libraries->count(); index++)
                if(m_libraries->at(index).getName() == "Blaze")
                    m_processor->setLibrary(&(m_libraries->operator [](index)));
            for(int index = 0; index < m_builds->count(); index++)
                if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "Blaze")
                    m_processor->setBuild(&(m_builds->operator [](index)));
            m_processor->setTest(&(m_tests->operator [](m_specInt)));
        } else {
            if(2 * maxProgress / 9 > m_specInt) {
                for(int index = 0; index < m_params->count(); index++) {
                    if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                        m_runParams->append(&(m_params->operator [](index)));
                }
                for(int index = 0; index < m_libraries->count(); index++)
                    if(m_libraries->at(index).getName() == "PanOpt")
                        m_processor->setLibrary(&(m_libraries->operator [](index)));
                for(int index = 0; index < m_builds->count(); index++)
                    if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "PanOpt")
                        m_processor->setBuild(&(m_builds->operator [](index)));
                m_processor->setTest(&(m_tests->operator [](m_specInt - (maxProgress / 9))));
            } else {
                if(3 * maxProgress / 9 > m_specInt) {
                    for(int index = 0; index < m_params->count(); index++) {
                        if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - 2 * (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                            m_runParams->append(&(m_params->operator [](index)));
                    }
                    for(int index = 0; index < m_libraries->count(); index++)
                        if(m_libraries->at(index).getName() == "C-like")
                            m_processor->setLibrary(&(m_libraries->operator [](index)));
                    for(int index = 0; index < m_builds->count(); index++)
                        if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "C-like")
                            m_processor->setBuild(&(m_builds->operator [](index)));
                    m_processor->setTest(&(m_tests->operator [](m_specInt - (2 * maxProgress / 9))));
                } else {
                    if(4 * maxProgress / 9 > m_specInt) {
                        for(int index = 0; index < m_params->count(); index++) {
                            if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - 3 * (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                                m_runParams->append(&(m_params->operator [](index)));
                        }
                        for(int index = 0; index < m_libraries->count(); index++)
                            if(m_libraries->at(index).getName() == "Classic")
                                m_processor->setLibrary(&(m_libraries->operator [](index)));
                        for(int index = 0; index < m_builds->count(); index++)
                            if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "Classic")
                                m_processor->setBuild(&(m_builds->operator [](index)));
                        m_processor->setTest(&(m_tests->operator [](m_specInt - (3 * maxProgress / 9))));
                    } else {
                        if(5 * maxProgress / 9 > m_specInt) {
                            for(int index = 0; index < m_params->count(); index++) {
                                if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - 4 * (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                                    m_runParams->append(&(m_params->operator [](index)));
                            }
                            for(int index = 0; index < m_libraries->count(); index++)
                                if(m_libraries->at(index).getName() == "Boost uBLAS")
                                    m_processor->setLibrary(&(m_libraries->operator [](index)));
                            for(int index = 0; index < m_builds->count(); index++)
                                if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "Boost uBLAS")
                                    m_processor->setBuild(&(m_builds->operator [](index)));
                            m_processor->setTest(&(m_tests->operator [](m_specInt - (4 * maxProgress / 9))));
                        } else {
                            if(6 * maxProgress / 9 > m_specInt) {
                                for(int index = 0; index < m_params->count(); index++) {
                                    if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - 5 * (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                                        m_runParams->append(&(m_params->operator [](index)));
                                }
                                for(int index = 0; index < m_libraries->count(); index++)
                                    if(m_libraries->at(index).getName() == "Blitz++")
                                        m_processor->setLibrary(&(m_libraries->operator [](index)));
                                for(int index = 0; index < m_builds->count(); index++)
                                    if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "Blitz++")
                                        m_processor->setBuild(&(m_builds->operator [](index)));
                                m_processor->setTest(&(m_tests->operator [](m_specInt - (5 * maxProgress / 9))));
                            } else {
                                if(7 * maxProgress / 9 > m_specInt) {
                                    for(int index = 0; index < m_params->count(); index++) {
                                        if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - 6 * (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                                            m_runParams->append(&(m_params->operator [](index)));
                                    }
                                    for(int index = 0; index < m_libraries->count(); index++)
                                        if(m_libraries->at(index).getName() == "GMM++")
                                            m_processor->setLibrary(&(m_libraries->operator [](index)));
                                    for(int index = 0; index < m_builds->count(); index++)
                                        if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "GMM++")
                                            m_processor->setBuild(&(m_builds->operator [](index)));
                                    m_processor->setTest(&(m_tests->operator [](m_specInt - (6 * maxProgress / 9))));
                                } else {
                                    if(8 * maxProgress / 9 > m_specInt) {
                                        for(int index = 0; index < m_params->count(); index++) {
                                            if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - 7 * (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                                                m_runParams->append(&(m_params->operator [](index)));
                                        }
                                        for(int index = 0; index < m_libraries->count(); index++)
                                            if(m_libraries->at(index).getName() == "MTL")
                                                m_processor->setLibrary(&(m_libraries->operator [](index)));
                                        for(int index = 0; index < m_builds->count(); index++)
                                            if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "MTL")
                                                m_processor->setBuild(&(m_builds->operator [](index)));
                                        m_processor->setTest(&(m_tests->operator [](m_specInt - (7 * maxProgress / 9))));
                                    } else {
                                        for(int index = 0; index < m_params->count(); index++) {
                                            if(m_params->at(index).getParentTestCategory()->getTestCategoryId() == m_tests->at(m_specInt - 8 * (maxProgress / 9)).getParentTestCategory()->getTestCategoryId())
                                                m_runParams->append(&(m_params->operator [](index)));
                                        }
                                        for(int index = 0; index < m_libraries->count(); index++)
                                            if(m_libraries->at(index).getName() == "Eigen")
                                                m_processor->setLibrary(&(m_libraries->operator [](index)));
                                        for(int index = 0; index < m_builds->count(); index++)
                                            if(m_builds->at(index).getParentVersion()->getParentLibrary()->getName() == "Eigen")
                                                m_processor->setBuild(&(m_builds->operator [](index)));
                                        m_processor->setTest(&(m_tests->operator [](m_specInt - (8 * maxProgress / 9))));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        m_specInt++;
        if(m_processor->getTest()->getName() != "smattrans" && m_processor->getTest()->getName() != "dmattrans") {
            ui->specButton->setText(QString("Progess: ") + QString::number(m_specInt) + QString("/") + QString::number(maxProgress));
            if(m_processor->getTest()->getName().count("mat") == 2 && m_processor->getTest()->getName().count("mult") == 1) {
                for(int newindex = 0; newindex < m_runParams->count();)
                    if(m_runParams->at(newindex)->getDimension() > 1000) {
                        m_runParams->removeAt(newindex);
                    } else {
                        newindex++;
                    }
            }
            m_processor->setParams(m_runParams);
            m_processor->moveToThread(m_procThread);
            connect(m_procThread, SIGNAL(started()), m_processor, SLOT(process()));
            connect(m_processor, SIGNAL(error()), this, SLOT(processError()));
            connect(m_processor, SIGNAL(finished()), this, SLOT(processReady()));
            m_procThread->start();
        } else { runSpecialTest(); }
    } else {
        ui->startTestButton->setText("Run selected tests");
        ui->startTestButton->setDisabled(0);
        ui->removeBuildButton->setDisabled(0);
        ui->specButton->setDisabled(0);
        ui->removeVersionButton->setDisabled(0);
        if(m_graphMode == 1) {
            ui->addGraphButton->setDisabled(0);
            ui->addGraphButton->setText("New Sweep..");
        }
        m_testRunning = 0;
        m_specInt = 0;
        ui->specButton->setText("Run all tests on PanOpt and Blaze");
        qDebug() << "Special test complete.";
    }
}

void MainWindow::processResult(int dim, float nzrF, QString result, Test * myTest, Build * myBuild) {
    int nzr = -1;
    if(nzrF > 0) {
        nzr = nzrF * dim * 0.01;
    }
    int index = -1, index2;
    if(dim == -1) { index = 0; } else {
        for(index = 0; index < m_params->count(); index++) {
            if(m_params->at(index).getDimension() == dim && m_params->at(index).getNonzeros() == nzr)
                break;
        }
    }
    for(index2 = 0; index2 < m_testCases->count(); index2++)
        if(m_params->at(index).getParamId() == m_testCases->at(index2).getParamId() && m_testCases->at(index2).getTestId() == myTest->getTestId())
            break;
    if(index2 == m_testCases->count()) {
        TestCase * newTestCase = new TestCase(m_conn);
        newTestCase->setParamId(m_params->at(index).getParamId());
        newTestCase->setParentParam(&(m_params->operator [](index)));
        newTestCase->setTestId(myTest->getTestId());
        index = -1;
        while(newTestCase->getTestId() != m_tests->at(++index).getTestId());
        newTestCase->setParentTest(&(m_tests->operator [](index)));
        newTestCase->save();
        m_testCases->append(*newTestCase);
    }
    for(index = 0; index < m_testResults->count(); index++)
        if(m_testResults->at(index).getTestCaseId() == m_testCases->at(index2).getTestCaseId() && m_testResults->at(index).getBuildId() == myBuild->getBuildId())
            break;
    if(index == m_testResults->count()) {
        TestResult * newTestResult = new TestResult(m_conn);
        newTestResult->setBuildId(myBuild->getBuildId());
        index = -1;
        while(newTestResult->getBuildId() != m_builds->at(++index).getBuildId());
        newTestResult->setParentBuild(&(m_builds->operator [](index)));
        newTestResult->setTestCaseId(m_testCases->at(index2).getTestCaseId());
        newTestResult->setParentTestCase(&(m_testCases->operator [](index2)));
        newTestResult->setTestResult(result);
        newTestResult->save();
        m_testResults->append(*newTestResult);
    } else {
        (m_testResults->operator [](index)).setTestResult(result);
        (m_testResults->operator [](index)).save();
    }
}

void MainWindow::processSweepResult(float paramF, QString result) {
    SweepResult * newSweepResult = new SweepResult(m_conn);
    newSweepResult->setSweepId(m_runningSweep->getSweepId());
    newSweepResult->setParamValue(paramF);
    newSweepResult->setResult(result);
    newSweepResult->save();
}

void MainWindow::sortParams(QList<Param> * paramList) {
    int index = 0, index2, minParam;
    for(;index < paramList->count() - 1; index++) {
        for(index2 = index, minParam = index; index2 < paramList->count(); index2++)
            if(paramList->at(index2).getDimension() < paramList->at(minParam).getDimension() || (paramList->at(index2).getDimension() == paramList->at(minParam).getDimension() && (paramList->at(index2).getNonzeros() / paramList->at(index2).getDimension()) < (paramList->at(minParam).getNonzeros() / paramList->at(minParam).getDimension())))
                minParam = index2;
        if(index != minParam)
            paramList->swap(index, minParam);
    }
}

void MainWindow::sortParams(QList<Param*> * paramList) {
    int index = 0, index2, minParam;
    for(;index < paramList->count() - 1; index++) {
        for(index2 = index, minParam = index; index2 < paramList->count(); index2++)
            if(paramList->at(index2)->getDimension() < paramList->at(minParam)->getDimension() || (paramList->at(index2)->getDimension() == paramList->at(minParam)->getDimension() && (paramList->at(index2)->getNonzeros() / paramList->at(index2)->getDimension()) < (paramList->at(minParam)->getNonzeros() / paramList->at(minParam)->getDimension())))
                minParam = index2;
        if(index != minParam)
            paramList->swap(index, minParam);
    }
}

void MainWindow::sortTestCases(QList<TestCase> * testCaseList) {
    QList<Param> * curParams = new QList<Param>;
    QList<float> * testCaseValues = new QList<float>;
    m_query->loadParams(curParams);
    int index, index2, minTestCase;
    for(index = 0; index < testCaseList->count(); index++) {
        index2 = -1;
        while(curParams->at(++index2).getParamId() != testCaseList->at(index).getParamId());
        if(curParams->at(index2).getNonzeros() > 0) {
            testCaseValues->append(curParams->at(index2).getDimension() + (100 * (float)curParams->at(index2).getNonzeros() / (float)curParams->at(index2).getDimension()));
        } else {
            testCaseValues->append(curParams->at(index2).getDimension());
        }
    }
    for(index = 0; index < testCaseList->count() - 1; index++) {
        for(index2 = index, minTestCase = index; index2 < testCaseList->count(); index2++)
            if(testCaseValues->at(index2) < testCaseValues->at(minTestCase))
                minTestCase = index2;
        if(index != minTestCase) {
            testCaseValues->swap(index, minTestCase);
            testCaseList->swap(index, minTestCase);
        }
    }
}

void MainWindow::sortTestResults(QList<TestResult *> *testResultList) {
    QList<Param> * curParams = new QList<Param>;
    QList<float> * testResultValues = new QList<float>;
    m_query->loadParams(curParams);
    int index, index2, minTestResult;
    for(index = 0; index < testResultList->count(); index++) {
        index2 = -1;
        while(curParams->at(++index2).getParamId() != testResultList->at(index)->getParentTestCase()->getParamId());
        if(curParams->at(index2).getNonzeros() > 0) {
            testResultValues->append(curParams->at(index2).getDimension() + (100 * (float)curParams->at(index2).getNonzeros() / (float)curParams->at(index2).getDimension()));
        } else {
            testResultValues->append(curParams->at(index2).getDimension());
        }
    }
    for(index = 0; index < testResultList->count() - 1; index++) {
        for(index2 = index, minTestResult = index; index2 < testResultList->count(); index2++)
            if(testResultValues->at(index2) < testResultValues->at(minTestResult))
                minTestResult = index2;
        if(index != minTestResult) {
            testResultValues->swap(index, minTestResult);
            testResultList->swap(index, minTestResult);
        }
    }
}

void MainWindow::parseTestName() {
    QString testName = m_selectedTest->getName(), descName = "";
    int index = 0;
    if(testName[index] == 't') {
        descName += "transpose ";
        index++;
    }
    if(testName[index] == 'd') {
        if(testName != "daxpy") {
            descName += "dense ";
            index++;
        } else {
            descName += "dense vectors daxpy product";
            index += descName.length();
        }
    } else {
        if(testName[index] == 's') {
            descName += "sparse ";
            index++;
        } else {
            descName += "Test description not available.";
            index += descName.length();
        }
    }
    if(index < descName.length()) {
        if(testName.mid(index, 3) == "vec") {
            descName += "vector ";
        } else {
            if(testName.mid(index, 3) == "mat") {
                descName += "matrix ";
            } else {
                descName = "Test description not available.";
                index += descName.length();
            }
        }
        index += 3;
    }
    if(index < descName.length()) {
        if(testName.count("norm")) {
            descName += "norm.";
            index += descName.length();
        } else {
            if(testName.count("scalarmult")) {
                descName += "scalar\nmultiplication";
                index += descName.length();
            } else {
                if(testName.count("trans")) {
                    descName += "transpose";
                    index += descName.length();
                } else {
                    descName += "-\n";
                    if(testName[index] == 't') {
                        descName += "transpose ";
                        index++;
                    }
                    if(testName[index] == 'd') {
                        descName += "dense ";
                        index++;
                    } else {
                        if(testName[index] == 's') {
                            descName += "sparse ";
                            index++;
                        } else {
                            descName += "Test description not available.";
                            index += descName.length();
                        }
                    }
                }
            }
        }
    }
    if(index < descName.length()) {
        if(testName.mid(index, 3) == "vec") {
            descName += "vector ";
        } else {
            if(testName.mid(index, 3) == "mat") {
                descName += "matrix ";
            } else {
                descName = "Test description not available.";
                index += descName.length();
            }
        }
        index += 3;
    }
    if(index < descName.length()) {
        if(testName.count("add")) {
            descName += "\naddition";
        }
        if(testName.count("sub")) {
            descName += "\nsubstraction";
        }
        if(testName.count("mult")) {
            descName += "\nmultiplication";
        }
    }
    ui->testDescLabel->setText(descName);
}

void MainWindow::parseBlazemarkOutput(QString myOutput, Test * myTest, Library * myLibrary, Build * myBuild) {
    QString curTitle, curResult, dimStr, nzrStr, resultStr;
    if(myOutput.count(":") > 1) {
        QStringList testList = myOutput.split(":");
        QStringListIterator it(testList); it.next(); curTitle = it.next(); curResult = it.next();
        curTitle = curTitle.trimmed();
        if(curTitle.indexOf('%') != -1) {
            nzrStr = curTitle.mid(curTitle.indexOf('(') + 1, curTitle.indexOf('%') - curTitle.indexOf('(') - 1);
        } else {
            nzrStr = "-1";
        }
        curTitle = curTitle.left(curTitle.indexOf(' '));
        while (it.hasNext()) {
            curResult = curResult.trimmed();
            while(curResult.indexOf(' ') != -1 && curResult.indexOf('N') != 0 && ((curResult.indexOf('[') > 25 && (curResult.indexOf('%') == -1 || curResult.indexOf('%') > 25)) || curResult.indexOf('[') == -1)) {
                dimStr = curResult.left(curResult.indexOf(' '));
                dimStr = dimStr.trimmed();
                curResult = curResult.mid(curResult.indexOf(' '), curResult.length() - curResult.indexOf(' '));
                curResult = curResult.trimmed();
                resultStr = curResult.left(curResult.indexOf(' '));
                resultStr = resultStr.trimmed();
                curResult = curResult.mid(curResult.indexOf(' '), curResult.length() - curResult.indexOf(' '));
                curResult = curResult.trimmed();
                if(m_testRunning == 2) {
                    if(m_runningSweep->getDimension() == -2) {
                        processSweepResult(dimStr.toInt(), resultStr);
                    }
                    if(m_runningSweep->getNonzeros() == -2) {
                        processSweepResult(nzrStr.toFloat(), resultStr);
                    }
                } else {
                    processResult(dimStr.toInt(), nzrStr.toFloat(), resultStr, myTest, myBuild);
                }
            }
            curTitle = curResult.trimmed();
            if(curTitle.indexOf('%') != -1) {
                nzrStr = curTitle.mid(curTitle.indexOf('(') + 1, curTitle.indexOf('%') - curTitle.indexOf('(') - 1);
            } else {
                nzrStr = "-1";
            }
            curTitle = curTitle.left(curTitle.indexOf(' '));
            curResult = it.next();
        }
        curResult = curResult.trimmed();
        while(curResult.indexOf(' ') != -1 && curResult.indexOf('N') != 0) {
            dimStr = curResult.left(curResult.indexOf(' '));
            dimStr = dimStr.trimmed();
            curResult = curResult.mid(curResult.indexOf(' '), curResult.length() - curResult.indexOf(' '));
            curResult = curResult.trimmed();
            resultStr = curResult.left(curResult.indexOf(' '));
            resultStr = resultStr.trimmed();
            curResult = curResult.mid(curResult.indexOf(' '), curResult.length() - curResult.indexOf(' '));
            curResult = curResult.trimmed();
            if(m_testRunning == 2) {
                if(m_runningSweep->getDimension() == -2) {
                    processSweepResult(dimStr.toInt(), resultStr);
                }
                if(m_runningSweep->getNonzeros() == -2) {
                    processSweepResult(nzrStr.toFloat(), resultStr);
                }
            } else {
                processResult(dimStr.toInt(), nzrStr.toFloat(), resultStr, myTest, myBuild);
            }
        }
    } else {
        if(m_testRunning == 2) {
            processSweepResult(-1, "Operation not supported by build.");
        } else {
            processResult(-1, -1, "Operation not supported by build.", myTest, myBuild);
        }
    }
}

void MainWindow::exitProgram() {
    this->destroy();
    QApplication::quit();
}

void MainWindow::processReady() {
    if(m_testRunning == 1) {
        parseBlazemarkOutput(m_processor->getProcess()->readAll(), m_processor->getTest(), m_processor->getLibrary(), m_processor->getBuild());
        loadResults();
        m_processor->deleteLater();
        m_procThread->quit();
        m_procThread->deleteLater();
        qDebug() << "Process thread finished.";
        ui->startTestButton->setText("Run selected tests");
        ui->startTestButton->setDisabled(0);
        ui->removeBuildButton->setDisabled(0);
        ui->specButton->setDisabled(0);
        ui->removeVersionButton->setDisabled(0);
        if(m_graphMode == 1) {
            ui->addGraphButton->setDisabled(0);
            ui->addGraphButton->setText("New Sweep..");
        }
        m_testRunning = 0;
        if(m_runBuilds->count() > m_runID || m_runTests->count() > m_runID) {
            runCurrentTest();
        } else {
            m_runBuilds->clear();
            m_runTests->clear();
        }
    }
    if(m_testRunning == 2) {
        parseBlazemarkOutput(m_processor->getProcess()->readAll(), m_processor->getTest(), m_processor->getLibrary(), m_processor->getBuild());
        m_processor->deleteLater();
        m_procThread->quit();
        m_procThread->deleteLater();
        qDebug() << "Process thread finished.";
        continueSweep();
    }
    if(m_testRunning == 3) {
        parseBlazemarkOutput(m_processor->getProcess()->readAll(), m_processor->getTest(), m_processor->getLibrary(), m_processor->getBuild());
        loadResults();
        m_processor->deleteLater();
        m_procThread->quit();
        m_procThread->deleteLater();
        qDebug() << "Process thread finished.";
        runSpecialTest();
    }
}

void MainWindow::processError() {
    if(m_testRunning == 1) {
        if(m_processor->getError() == QString("Test time limit reached."))
            processResult(-1, -1, m_processor->getError(), m_processor->getTest(), m_processor->getBuild());
        loadResults();
        m_processor->deleteLater();
        m_procThread->quit();
        m_procThread->deleteLater();
        qDebug() << "Process thread finished with error.";
        ui->startTestButton->setText("Run selected tests");
        ui->startTestButton->setDisabled(0);
        ui->removeBuildButton->setDisabled(0);
        ui->specButton->setDisabled(0);
        ui->removeVersionButton->setDisabled(0);
        if(m_graphMode == 1) {
            ui->addGraphButton->setDisabled(0);
            ui->addGraphButton->setText("New Sweep..");
        }
        m_testRunning = 0;
        m_runningSweep = NULL;
        if(m_runBuilds->count() > m_runID || m_runTests->count() > m_runID) {
            runCurrentTest();
        } else {
            m_runBuilds->clear();
            m_runTests->clear();
        }
    }
    if(m_testRunning == 2) {
        if(m_processor->getError() == QString("Test time limit reached."))
            processResult(-1, -1, m_processor->getError(), m_processor->getTest(), m_processor->getBuild());
        loadResults();
        m_processor->deleteLater();
        m_procThread->quit();
        m_procThread->deleteLater();
        qDebug() << "Process thread finished with error.";
        ui->startTestButton->setText("Run selected tests");
        ui->startTestButton->setDisabled(0);
        ui->removeBuildButton->setDisabled(0);
        ui->specButton->setDisabled(0);
        ui->removeVersionButton->setDisabled(0);
        if(m_graphMode == 1) {
            ui->addGraphButton->setDisabled(0);
            ui->addGraphButton->setText("New Sweep..");
        }
        m_testRunning = 0;
        m_runningSweep = NULL;
        if(m_runBuilds->count() > m_runID || m_runTests->count() > m_runID) {
            runCurrentTest();
        } else {
            m_runBuilds->clear();
            m_runTests->clear();
        }
    }
    if(m_testRunning == 3) {
        if(m_processor->getError() == QString("Test time limit reached."))
            processResult(-1, -1, m_processor->getError(), m_processor->getTest(), m_processor->getBuild());
        loadResults();
        m_processor->deleteLater();
        m_procThread->quit();
        m_procThread->deleteLater();
        qDebug() << "Process thread finished with error.";
        runSpecialTest();
    }
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    QCoreApplication::setOrganizationName("University of Pannonia");
    QCoreApplication::setOrganizationDomain("www.uni-pannon.hu");
    QCoreApplication::setApplicationName("BlazemarkAnalyser");

    qDebug() << "Initializing main objects..";
    ui->setupUi(this);
    m_conn = new SqliteConnector();
    m_libraries = new QList<Library>();
    m_versions = new QList<Version>();
    m_builds = new QList<Build>();
    m_runBuilds = new QList<Build*>();
    m_tests = new QList<Test>();
    m_runTests = new QList<Test*>();
    m_params = new QList<Param>();
    m_shownParams = new QList<Param*>();
    m_runParams = new QList<Param*>();
    m_testCategories = new QList<TestCategory>();
    m_testCases = new QList<TestCase>();
    m_testResults = new QList<TestResult>();
    m_shownResults = new QList<TestResult*>();
    m_graphResults = new QSet<TestResult*>();
    m_sweeps = new QList<Sweep>();
    m_selectedSweeps = new QList<Sweep*>();
    m_shownSweeps = new QList<Sweep*>();
    m_sweepResults = new QList<SweepResult>();
    m_selectedBuild = NULL;
    m_selectedLibrary = NULL;
    m_selectedParam = NULL;
    m_selectedTest = NULL;
    m_selectedTestCase = NULL;
    m_selectedTestResult = NULL;
    m_selectedVersion = NULL;
    m_runningSweep = NULL;
    m_query = new DatabaseQuery(m_conn);
    m_working = false;
    m_testRunning = 0;
    m_sweepProgress = -1;
    m_runID = 0;
    m_graphMode = 0;
    m_specInt = 0;
    m_processor = NULL;
    m_process = NULL;
    m_procThread = NULL;
    m_scene = NULL;
    m_descScene = NULL;
    m_settings = new QSettings();

    qDebug() << "Setting up GUI..";
    ui->testList->setEditTriggers(QTableWidget::NoEditTriggers);

    connect(ui->actionExit, SIGNAL(triggered()), this, SLOT(exitProgram()));
    ui->paramTable->setSelectionMode(QAbstractItemView::NoSelection);
    ui->paramTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->paramTable->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->paramTable->verticalHeader()->setFixedWidth(0);
    ui->paramTable->setEditTriggers(QTableWidget::NoEditTriggers);

    ui->resultLabel = new QLabel;
    ui->resultLabel->setAlignment(Qt::AlignTop);
    ui->resultLabel->setGeometry(15,15,741,100);
    ui->resultLabel->setMargin(10);
    ui->resultLabel->setTextFormat(Qt::RichText);
    ui->resultLabel->setText(QString("<html>No results.</html>"));
    ui->resultLabel->setGeometry(15,15,741, ui->resultLabel->fontMetrics().lineSpacing() * (2 + ui->resultLabel->text().count("<tr>")));
    ui->c_resultScrollArea->setWidget(ui->resultLabel);

    ui->delResultsButton->setDisabled(true);
    ui->editParamsButton->setDisabled(true);
    ui->resetParamsButton->setDisabled(true);

    ui->libraryDescription->setReadOnly(true);
    ui->versionDescription->setReadOnly(true);

    ui->libraryUrlLabel->setOpenExternalLinks(true);

    clearGraph();

    qDebug() << "Loading Entities..";
    loadEntities();

    qDebug() << "BlazemarkAnalyser initialization successful.";

    ui->specButton->setDisabled(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_testList_itemClicked(QListWidgetItem *)
{
    if(!m_working)
        selectTest();
}

void MainWindow::on_testList_itemSelectionChanged()
{
    if(!m_working)
        selectTest();
}

void MainWindow::on_libraryList_itemClicked(QListWidgetItem *)
{
    if(!m_working)
        selectLibrary();
}

void MainWindow::on_libraryList_itemSelectionChanged()
{
    if(!m_working)
        selectLibrary();
}

void MainWindow::on_versionList_itemSelectionChanged()
{
    if(!m_working)
        selectVersion();
}

void MainWindow::on_versionList_itemClicked(QListWidgetItem *)
{
    if(!m_working)
        selectVersion();
}

void MainWindow::on_buildList_itemClicked(QListWidgetItem *)
{
    if(!m_working)
        selectBuild();
}

void MainWindow::on_buildList_itemSelectionChanged()
{
    if(!m_working)
        selectBuild();
}

void MainWindow::on_startTestButton_clicked()
{
    m_runParams->clear();
    m_runParams->append(*m_shownParams);
    m_runID = 0;
    runCurrentTest();
}

void MainWindow::on_delResultsButton_clicked()
{
    clearResults();
}

void MainWindow::on_removeBuildButton_clicked()
{
    m_dialog.makeRemoveDialog(m_selectedBuild, m_conn);
    m_dialog.exec();

    m_builds->clear();
    m_testResults->clear();

    for(int index = 0; index < m_versions->count(); index++)
        m_query->loadBuildsByVersion(m_builds, &(m_versions->operator [](index)));

    for(int index = 0; index < m_builds->count(); index++)
        for(int index2 = 0; index2 < m_testCases->count(); index2++)
            m_query->loadTestResultsByAll(m_testResults, &(m_builds->operator [](index)), &(m_testCases->operator [](index2)));


    selectVersion();
}

void MainWindow::on_removeVersionButton_clicked()
{
    m_dialog.makeRemoveDialog(m_selectedVersion, m_conn);
    m_dialog.exec();

    m_versions->clear();
    m_builds->clear();
    m_testResults->clear();

    for(int index = 0; index < m_libraries->count(); index++)
        m_query->loadVersionsByLibrary(m_versions, &(m_libraries->operator [](index)));

    for(int index = 0; index < m_versions->count(); index++)
        m_query->loadBuildsByVersion(m_builds, &(m_versions->operator [](index)));

    for(int index = 0; index < m_builds->count(); index++)
        for(int index2 = 0; index2 < m_testCases->count(); index2++)
            m_query->loadTestResultsByAll(m_testResults, &(m_builds->operator [](index)), &(m_testCases->operator [](index2)));

    selectLibrary();
}

void MainWindow::on_addVersionButton_clicked()
{
    m_selectedVersion = new Version(m_conn);
    m_dialog.makeVersionDialog(m_selectedLibrary, m_selectedVersion);
    m_dialog.exec();

    m_versions->clear();
    m_builds->clear();
    m_testResults->clear();

    for(int index = 0; index < m_libraries->count(); index++)
        m_query->loadVersionsByLibrary(m_versions, &(m_libraries->operator [](index)));

    for(int index = 0; index < m_versions->count(); index++)
        m_query->loadBuildsByVersion(m_builds, &(m_versions->operator [](index)));

    for(int index = 0; index < m_builds->count(); index++)
        for(int index2 = 0; index2 < m_testCases->count(); index2++)
            m_query->loadTestResultsByAll(m_testResults, &(m_builds->operator [](index)), &(m_testCases->operator [](index2)));

    selectLibrary();
}

void MainWindow::on_addBuildButton_clicked()
{
    m_selectedBuild = new Build(m_conn);
    m_dialog.makeBuildDialog(m_selectedVersion, m_selectedBuild);
    m_dialog.exec();

    m_builds->clear();
    m_testResults->clear();

    for(int index = 0; index < m_versions->count(); index++)
        m_query->loadBuildsByVersion(m_builds, &(m_versions->operator [](index)));

    for(int index = 0; index < m_builds->count(); index++)
        for(int index2 = 0; index2 < m_testCases->count(); index2++)
            m_query->loadTestResultsByAll(m_testResults, &(m_builds->operator [](index)), &(m_testCases->operator [](index2)));

    selectVersion();
}

void MainWindow::on_clearGraphButton_clicked()
{
    if(m_graphMode == 0) clearGraph();
    if(m_graphMode == 1) {
        QList<int> * intList = new QList<int>();
        QList<SweepResult> * resultsSoFar = new QList<SweepResult>;
        for(int index = 0; index < m_selectedSweeps->count(); index++) {
            resultsSoFar->clear();
            m_query->loadSweepResultsBySweep(resultsSoFar, m_selectedSweeps->at(index));
            intList->append(resultsSoFar->count());
        }
        Sweep * mySweep = new Sweep(m_conn);

        //!!!!!!!!!!! TODO RIGHT AFTER FINISHED SWEEPS DIALOG DOES NOT SHOW ACCURATE RESULTS

        m_dialog.makeSweepManagementDialog(m_selectedSweeps, intList, &mySweep, ui->graphBuildList->currentText());
        m_dialog.exec();
        if(mySweep != NULL) {
            if(mySweep->getParentBuild() == NULL) {
                m_working = true;
                m_sweeps->clear();
                for(int index = 0; index < m_builds->count(); index++)
                    for(int index2 = 0; index2 < m_tests->count(); index2++)
                        m_query->loadSweepsByAll(m_sweeps, &(m_tests->operator [](index2)), &(m_builds->operator [](index)));
                m_working = false;
                updateGraphButton();
            } else {
                int swID = -1;
                while(m_selectedSweeps->at(++swID)->getSweepId() != mySweep->getSweepId());
                if(mySweep->getSweepCount() > intList->at(swID)) {
                    m_runningSweep = mySweep;
                    continueSweep();
                } else {
                    if(m_shownSweeps->count() > 0 && (m_shownSweeps->at(0)->getDimension() != m_selectedSweeps->at(swID)->getDimension() || m_shownSweeps->at(0)->getNonzeros() != m_selectedSweeps->at(swID)->getNonzeros() ||
                       m_shownSweeps->at(0)->getSweepMin() != m_selectedSweeps->at(swID)->getSweepMin() || m_shownSweeps->at(0)->getSweepMax() != m_selectedSweeps->at(swID)->getSweepMax() ||
                       m_shownSweeps->at(0)->getScaling() != m_selectedSweeps->at(swID)->getScaling()))
                        m_shownSweeps->clear();
                    m_shownSweeps->append(m_selectedSweeps->operator [](swID));
                    showSweep();
                }
            }
        }
    }
}

void MainWindow::on_graphTestList_currentIndexChanged(int)
{
    if(m_graphMode == 0) {
        selectGraphTest();
    }
    if(m_graphMode == 1) {
        updateGraphButton();
    }
}

void MainWindow::on_graphLibraryList_currentIndexChanged(int)
{
    selectGraphLibrary();
}

void MainWindow::on_graphVersionList_currentIndexChanged(int)
{
    selectGraphVersion();
}

void MainWindow::on_graphBuildList_currentIndexChanged(int)
{
    if(!m_working && m_graphMode == 1) { updateGraphButton(); }
}

void MainWindow::on_addGraphButton_clicked()
{
    if(m_graphMode == 0) {
        if(ui->addGraphButton->text() == "Add build results") {
            showGraph();
        } else {
            showGraph(false);
        }
    }
    if(m_graphMode == 1 && m_testRunning == 2) {
        disconnect(m_procThread, SIGNAL(started()), m_processor, SLOT(process()));
        disconnect(m_processor, SIGNAL(error()), this, SLOT(processError()));
        disconnect(m_processor, SIGNAL(finished()), this, SLOT(processReady()));
        m_processor->killNow();
        m_procThread->terminate();
        m_procThread->quit();
        m_processor->deleteLater();
        qDebug() << "Process thread cancelled by user.";
        ui->startTestButton->setText("Run selected tests");
        ui->startTestButton->setDisabled(0);
        ui->removeBuildButton->setDisabled(0);
        ui->specButton->setDisabled(0);
        ui->removeVersionButton->setDisabled(0);
        ui->addGraphButton->setText("New Sweep..");
        m_testRunning = 0;
    } else {
        if(m_graphMode == 1 && m_testRunning == 0) {
            int testID = -1, buildID = -1;
            while(ui->graphTestList->itemData(ui->graphTestList->currentIndex()) != m_tests->at(++testID).getTestId());
            while(ui->graphBuildList->itemData(ui->graphBuildList->currentIndex()) != m_builds->at(++buildID).getBuildId());
            Sweep * mySweep = new Sweep(m_conn);
            m_dialog.makeSweepDialog(&(m_tests->operator [](testID)), &(m_builds->operator [](buildID)), ui->graphBuildList->currentText(), mySweep);
            m_dialog.exec();

            m_sweeps->clear();
            for(int index = 0; index < m_builds->count(); index++)
                for(int index2 = 0; index2 < m_tests->count(); index2++)
                    m_query->loadSweepsByAll(m_sweeps, &(m_tests->operator [](index2)), &(m_builds->operator [](index)));

            if(mySweep->getSweepId() != INVALID_ID) {
                m_runningSweep = mySweep;
                continueSweep();
            }
        }
    }
}

void MainWindow::on_compareModeRadio_toggled(bool checked)
{
    if(checked) {
        m_working = true;
        clearGraph();
        m_graphMode = 0;
        ui->addGraphButton->setDisabled(0);
        ui->addGraphButton->setText("Add build Results");
        ui->clearGraphButton->setText("Clear graph");
        m_working = false;
        selectGraphTest();
    }
}

void MainWindow::on_sweepModeRadio_toggled(bool checked)
{
    if(checked) {
        clearGraph();
        if(m_testRunning == 1)
            ui->addGraphButton->setDisabled(1);
        if(m_testRunning == 2)
            ui->addGraphButton->setText(QString("Cancel sweep (") + QString::number(m_sweepProgress) + QString("%)"));
        if(m_testRunning == 0)
            ui->addGraphButton->setText("New Sweep..");
        m_working = true;
        ui->clearGraphButton->setText("Manage sweeps");
        ui->graphLibraryList->clear();
        ui->graphVersionList->clear();
        ui->graphBuildList->clear();
        m_graphMode = 1;
        for(int index = 0; index < m_libraries->count(); index++) {
            ui->graphLibraryList->addItem(m_libraries->at(index).getName(), m_libraries->at(index).getLibraryId());
        }
        selectGraphLibrary();
    }
}

void MainWindow::on_specButton_clicked()
{
    m_specInt = 132;
    runSpecialTest();
}
